(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures/fixtures_websites.js                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//Document Websites                                                    //
if (Websites.find().count() === 0) {                                   // 2
    Websites.insert({                                                  // 3
        _id: '1',                                                      // 4
        name: 'Apec',                                                  // 5
        url: 'https://cadres.apec.fr/',                                // 6
        logo: '/images/apec.png'                                       // 7
    });                                                                //
    Websites.insert({                                                  // 9
        _id: '2',                                                      // 10
        name: 'Cadremploi',                                            // 11
        url: 'http://www.cadremploi.fr/',                              // 12
        logo: '/images/cadremploi.png'                                 // 13
    });                                                                //
    Websites.insert({                                                  // 15
        _id: '3',                                                      // 16
        name: 'Indeed',                                                // 17
        url: 'http://www.indeed.fr/',                                  // 18
        logo: '/images/indeed.png'                                     // 19
    });                                                                //
    Websites.insert({                                                  // 21
        _id: '4',                                                      // 22
        name: 'Keljob',                                                // 23
        url: 'https://www.keljob.com/',                                // 24
        logo: '/images/keljob.png'                                     // 25
    });                                                                //
    Websites.insert({                                                  // 27
        _id: '5',                                                      // 28
        name: 'Remixjobs',                                             // 29
        url: 'https://remixjobs.com/',                                 // 30
        logo: '/images/remixjobs.png'                                  // 31
    });                                                                //
    Websites.insert({                                                  // 33
        _id: '6',                                                      // 34
        name: 'Monster',                                               // 35
        url: 'http://www.monster.fr/',                                 // 36
        logo: '/images/monster.png'                                    // 37
    });                                                                //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures_websites.js.map
