(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures/fixtures_dep_reg.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Données préenregistrées                                             //
if (Regions.find().count() === 0) {                                    // 2
    Regions.insert({                                                   // 3
        _id: '42',                                                     // 4
        name: 'Alsace',                                                // 5
        websites: {                                                    // 6
            Apec: '700'                                                // 7
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 10
        _id: '72',                                                     // 11
        name: 'Aquitaine',                                             // 12
        websites: {                                                    // 13
            Apec: '701'                                                // 14
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 17
        _id: '83',                                                     // 18
        name: 'Auvergne',                                              // 19
        websites: {                                                    // 20
            Apec: '702'                                                // 21
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 24
        _id: '25',                                                     // 25
        name: 'Basse Normandie',                                       // 26
        websites: {                                                    // 27
            Apec: '703'                                                // 28
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 31
        _id: '26',                                                     // 32
        name: 'Bourgogne',                                             // 33
        websites: {                                                    // 34
            Apec: '704'                                                // 35
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 38
        _id: '53',                                                     // 39
        name: 'Bretagne',                                              // 40
        websites: {                                                    // 41
            Apec: '705'                                                // 42
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 45
        _id: '24',                                                     // 46
        name: 'Centre',                                                // 47
        websites: {                                                    // 48
            Apec: '706'                                                // 49
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 52
        _id: '21',                                                     // 53
        name: 'Champagne Ardenne',                                     // 54
        websites: {                                                    // 55
            Apec: '707'                                                // 56
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 59
        _id: '94',                                                     // 60
        name: 'Corse',                                                 // 61
        websites: {                                                    // 62
            Apec: '20'                                                 // 63
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 66
        _id: '43',                                                     // 67
        name: 'Franche Comté',                                         // 68
        websites: {                                                    // 69
            Apec: '709'                                                // 70
        }                                                              //
    });                                                                //
    /*Regions.insert({                                                 //
        _id: '01',                                                     //
        name: 'Guadeloupe',                                            //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Regions.insert({                                                   //
        _id: '03',                                                     //
        name: 'Guyane',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });*/                                                              //
    Regions.insert({                                                   // 87
        _id: '23',                                                     // 88
        name: 'Haute Normandie',                                       // 89
        websites: {                                                    // 90
            Apec: '710'                                                // 91
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 94
        _id: '11',                                                     // 95
        name: 'Île de France',                                         // 96
        websites: {                                                    // 97
            Apec: '711'                                                // 98
        }                                                              //
    });                                                                //
    /*Regions.insert({                                                 //
        _id: '04',                                                     //
        name: 'La Réunion',                                            //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });*/                                                              //
    Regions.insert({                                                   // 108
        _id: '91',                                                     // 109
        name: 'Languedoc Roussillon',                                  // 110
        websites: {                                                    // 111
            Apec: '712'                                                // 112
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 115
        _id: '74',                                                     // 116
        name: 'Limousin',                                              // 117
        websites: {                                                    // 118
            Apec: '713'                                                // 119
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 122
        _id: '41',                                                     // 123
        name: 'Lorraine',                                              // 124
        websites: {                                                    // 125
            Apec: '714'                                                // 126
        }                                                              //
    });                                                                //
    /*Regions.insert({                                                 //
        _id: '02',                                                     //
        name: 'Martinique',                                            //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Regions.insert({                                                   //
        _id: '06',                                                     //
        name: 'Mayotte',                                               //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });*/                                                              //
    Regions.insert({                                                   // 143
        _id: '73',                                                     // 144
        name: 'Midi Pyrénées',                                         // 145
        websites: {                                                    // 146
            Apec: '715'                                                // 147
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 150
        _id: '31',                                                     // 151
        name: 'Nord Pas de Calais',                                    // 152
        websites: {                                                    // 153
            Apec: '716'                                                // 154
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 157
        _id: '52',                                                     // 158
        name: 'Pays de la Loire',                                      // 159
        websites: {                                                    // 160
            Apec: '717'                                                // 161
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 164
        _id: '22',                                                     // 165
        name: 'Picardie',                                              // 166
        websites: {                                                    // 167
            Apec: '718'                                                // 168
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 171
        _id: '54',                                                     // 172
        name: 'Poitou Charentes',                                      // 173
        websites: {                                                    // 174
            Apec: '719'                                                // 175
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 178
        _id: '93',                                                     // 179
        name: 'Provence Alpes Côte d\'Azur',                           // 180
        websites: {                                                    // 181
            Apec: '720'                                                // 182
        }                                                              //
    });                                                                //
    Regions.insert({                                                   // 185
        _id: '82',                                                     // 186
        name: 'Rhône Alpes',                                           // 187
        websites: {                                                    // 188
            Apec: '721'                                                // 189
        }                                                              //
    });                                                                //
}                                                                      //
                                                                       //
// Données préenregistrées                                             //
if (Departements.find().count() === 0) {                               // 195
    Departements.insert({                                              // 196
        _id: '01',                                                     // 197
        name: 'Ain',                                                   // 198
        regionId: '82',                                                // 199
        websites: {                                                    // 200
            Apec: '011'                                                // 201
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 204
        _id: '02',                                                     // 205
        name: 'Aisne',                                                 // 206
        regionId: '22',                                                // 207
        websites: {                                                    // 208
            Apec: '02'                                                 // 209
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 212
        _id: '03',                                                     // 213
        name: 'Allier',                                                // 214
        regionId: '83',                                                // 215
        websites: {                                                    // 216
            Apec: '033'                                                // 217
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 220
        _id: '04',                                                     // 221
        name: 'Alpes de Haute Provence',                               // 222
        regionId: '93',                                                // 223
        websites: {                                                    // 224
            Apec: '04'                                                 // 225
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 228
        _id: '05',                                                     // 229
        name: 'Hautes Alpes',                                          // 230
        regionId: '93',                                                // 231
        websites: {                                                    // 232
            Apec: '05'                                                 // 233
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 236
        _id: '06',                                                     // 237
        name: 'Alpes Maritimes',                                       // 238
        regionId: '93',                                                // 239
        websites: {                                                    // 240
            Apec: '06'                                                 // 241
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 244
        _id: '07',                                                     // 245
        name: 'Ardèche',                                               // 246
        regionId: '82',                                                // 247
        websites: {                                                    // 248
            Apec: '07'                                                 // 249
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 252
        _id: '08',                                                     // 253
        name: 'Ardennes',                                              // 254
        regionId: '21',                                                // 255
        websites: {                                                    // 256
            Apec: '08'                                                 // 257
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 260
        _id: '09',                                                     // 261
        name: 'Ariège',                                                // 262
        regionId: '73',                                                // 263
        websites: {                                                    // 264
            Apec: '09'                                                 // 265
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 268
        _id: '10',                                                     // 269
        name: 'Aube',                                                  // 270
        regionId: '21',                                                // 271
        websites: {                                                    // 272
            Apec: '10'                                                 // 273
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 276
        _id: '11',                                                     // 277
        name: 'Aude',                                                  // 278
        regionId: '91',                                                // 279
        websites: {                                                    // 280
            Apec: '11'                                                 // 281
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 284
        _id: '12',                                                     // 285
        name: 'Aveyron',                                               // 286
        regionId: '73',                                                // 287
        websites: {                                                    // 288
            Apec: '12'                                                 // 289
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 292
        _id: '13',                                                     // 293
        name: 'Bouches du Rhône',                                      // 294
        regionId: '93',                                                // 295
        websites: {                                                    // 296
            Apec: '13'                                                 // 297
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 300
        _id: '14',                                                     // 301
        name: 'Calvados',                                              // 302
        regionId: '25',                                                // 303
        websites: {                                                    // 304
            Apec: '14'                                                 // 305
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 308
        _id: '15',                                                     // 309
        name: 'Cantal',                                                // 310
        regionId: '83',                                                // 311
        websites: {                                                    // 312
            Apec: '15'                                                 // 313
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 316
        _id: '16',                                                     // 317
        name: 'Charente',                                              // 318
        regionId: '54',                                                // 319
        websites: {                                                    // 320
            Apec: '16'                                                 // 321
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 324
        _id: '17',                                                     // 325
        name: 'Charente Maritime',                                     // 326
        regionId: '54',                                                // 327
        websites: {                                                    // 328
            Apec: '17'                                                 // 329
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 332
        _id: '18',                                                     // 333
        name: 'Cher',                                                  // 334
        regionId: '24',                                                // 335
        websites: {                                                    // 336
            Apec: '18'                                                 // 337
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 340
        _id: '19',                                                     // 341
        name: 'Corrèze',                                               // 342
        regionId: '74',                                                // 343
        websites: {                                                    // 344
            Apec: '19'                                                 // 345
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 348
        _id: '2A',                                                     // 349
        name: 'Corse du Sud',                                          // 350
        regionId: '94',                                                // 351
        websites: {                                                    // 352
            Apec: '750'                                                // 353
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 356
        _id: '2B',                                                     // 357
        name: 'Haute Corse',                                           // 358
        regionId: '94',                                                // 359
        websites: {                                                    // 360
            Apec: '751'                                                // 361
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 364
        _id: '21',                                                     // 365
        name: 'Côte d\'Or',                                            // 366
        regionId: '26',                                                // 367
        websites: {                                                    // 368
            Apec: '21'                                                 // 369
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 372
        _id: '22',                                                     // 373
        name: 'Côtes d\'Armor',                                        // 374
        regionId: '53',                                                // 375
        websites: {                                                    // 376
            Apec: '22'                                                 // 377
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 380
        _id: '23',                                                     // 381
        name: 'Creuse',                                                // 382
        regionId: '74',                                                // 383
        websites: {                                                    // 384
            Apec: '23'                                                 // 385
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 388
        _id: '24',                                                     // 389
        name: 'Dordogne',                                              // 390
        regionId: '72',                                                // 391
        websites: {                                                    // 392
            Apec: '24'                                                 // 393
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 396
        _id: '25',                                                     // 397
        name: 'Doubs',                                                 // 398
        regionId: '43',                                                // 399
        websites: {                                                    // 400
            Apec: '25'                                                 // 401
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 404
        _id: '26',                                                     // 405
        name: 'Drôme',                                                 // 406
        regionId: '82',                                                // 407
        websites: {                                                    // 408
            Apec: '26'                                                 // 409
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 412
        _id: '27',                                                     // 413
        name: 'Eure',                                                  // 414
        regionId: '23',                                                // 415
        websites: {                                                    // 416
            Apec: '27'                                                 // 417
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 420
        _id: '28',                                                     // 421
        name: 'Eure et Loir',                                          // 422
        regionId: '24',                                                // 423
        websites: {                                                    // 424
            Apec: '28'                                                 // 425
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 428
        _id: '29',                                                     // 429
        name: 'Finistère',                                             // 430
        regionId: '53',                                                // 431
        websites: {                                                    // 432
            Apec: '29'                                                 // 433
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 436
        _id: '30',                                                     // 437
        name: 'Gard',                                                  // 438
        regionId: '91',                                                // 439
        websites: {                                                    // 440
            Apec: '30'                                                 // 441
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 444
        _id: '31',                                                     // 445
        name: 'Haute Garonne',                                         // 446
        regionId: '73',                                                // 447
        websites: {                                                    // 448
            Apec: '31'                                                 // 449
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 452
        _id: '32',                                                     // 453
        name: 'Gers',                                                  // 454
        regionId: '73',                                                // 455
        websites: {                                                    // 456
            Apec: '32'                                                 // 457
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 460
        _id: '33',                                                     // 461
        name: 'Gironde',                                               // 462
        regionId: '72',                                                // 463
        websites: {                                                    // 464
            Apec: '33'                                                 // 465
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 468
        _id: '34',                                                     // 469
        name: 'Hérault',                                               // 470
        regionId: '91',                                                // 471
        websites: {                                                    // 472
            Apec: '34'                                                 // 473
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 476
        _id: '35',                                                     // 477
        name: 'Ille et Vilaine',                                       // 478
        regionId: '53',                                                // 479
        websites: {                                                    // 480
            Apec: '35'                                                 // 481
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 484
        _id: '36',                                                     // 485
        name: 'Indre',                                                 // 486
        regionId: '24',                                                // 487
        websites: {                                                    // 488
            Apec: '36'                                                 // 489
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 492
        _id: '37',                                                     // 493
        name: 'Indre et Loire',                                        // 494
        regionId: '24',                                                // 495
        websites: {                                                    // 496
            Apec: '37'                                                 // 497
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 500
        _id: '38',                                                     // 501
        name: 'Isère',                                                 // 502
        regionId: '82',                                                // 503
        websites: {                                                    // 504
            Apec: '38'                                                 // 505
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 508
        _id: '39',                                                     // 509
        name: 'Jura',                                                  // 510
        regionId: '43',                                                // 511
        websites: {                                                    // 512
            Apec: '39'                                                 // 513
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 516
        _id: '40',                                                     // 517
        name: 'Landes',                                                // 518
        regionId: '72',                                                // 519
        websites: {                                                    // 520
            Apec: '40'                                                 // 521
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 524
        _id: '41',                                                     // 525
        name: 'Loir et Cher',                                          // 526
        regionId: '24',                                                // 527
        websites: {                                                    // 528
            Apec: '41'                                                 // 529
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 532
        _id: '42',                                                     // 533
        name: 'Loire',                                                 // 534
        regionId: '82',                                                // 535
        websites: {                                                    // 536
            Apec: '42'                                                 // 537
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 540
        _id: '43',                                                     // 541
        name: 'Haute Loire',                                           // 542
        regionId: '83',                                                // 543
        websites: {                                                    // 544
            Apec: '43'                                                 // 545
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 548
        _id: '44',                                                     // 549
        name: 'Loire Atlantique',                                      // 550
        regionId: '52',                                                // 551
        websites: {                                                    // 552
            Apec: '44'                                                 // 553
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 556
        _id: '45',                                                     // 557
        name: 'Loiret',                                                // 558
        regionId: '24',                                                // 559
        websites: {                                                    // 560
            Apec: '45'                                                 // 561
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 564
        _id: '46',                                                     // 565
        name: 'Lot',                                                   // 566
        regionId: '73',                                                // 567
        websites: {                                                    // 568
            Apec: '46'                                                 // 569
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 572
        _id: '47',                                                     // 573
        name: 'Lot et Garonne',                                        // 574
        regionId: '72',                                                // 575
        websites: {                                                    // 576
            Apec: '47'                                                 // 577
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 580
        _id: '48',                                                     // 581
        name: 'Lozère',                                                // 582
        regionId: '91',                                                // 583
        websites: {                                                    // 584
            Apec: '48'                                                 // 585
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 588
        _id: '49',                                                     // 589
        name: 'Maine et Loire',                                        // 590
        regionId: '52',                                                // 591
        websites: {                                                    // 592
            Apec: '49'                                                 // 593
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 596
        _id: '50',                                                     // 597
        name: 'Manche',                                                // 598
        regionId: '25',                                                // 599
        websites: {                                                    // 600
            Apec: '50'                                                 // 601
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 604
        _id: '51',                                                     // 605
        name: 'Marne',                                                 // 606
        regionId: '21',                                                // 607
        websites: {                                                    // 608
            Apec: '51'                                                 // 609
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 612
        _id: '52',                                                     // 613
        name: 'Haute Marne',                                           // 614
        regionId: '21',                                                // 615
        websites: {                                                    // 616
            Apec: '52'                                                 // 617
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 620
        _id: '53',                                                     // 621
        name: 'Mayenne',                                               // 622
        regionId: '52',                                                // 623
        websites: {                                                    // 624
            Apec: '53'                                                 // 625
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 628
        _id: '54',                                                     // 629
        name: 'Meurthe et Moselle',                                    // 630
        regionId: '41',                                                // 631
        websites: {                                                    // 632
            Apec: '54'                                                 // 633
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 636
        _id: '55',                                                     // 637
        name: 'Meuse',                                                 // 638
        regionId: '41',                                                // 639
        websites: {                                                    // 640
            Apec: '55'                                                 // 641
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 644
        _id: '56',                                                     // 645
        name: 'Morbihan',                                              // 646
        regionId: '53',                                                // 647
        websites: {                                                    // 648
            Apec: '56'                                                 // 649
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 652
        _id: '57',                                                     // 653
        name: 'Moselle',                                               // 654
        regionId: '41',                                                // 655
        websites: {                                                    // 656
            Apec: '57'                                                 // 657
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 660
        _id: '58',                                                     // 661
        name: 'Nièvre',                                                // 662
        regionId: '26',                                                // 663
        websites: {                                                    // 664
            Apec: '58'                                                 // 665
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 668
        _id: '59',                                                     // 669
        name: 'Nord',                                                  // 670
        regionId: '31',                                                // 671
        websites: {                                                    // 672
            Apec: '59'                                                 // 673
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 676
        _id: '60',                                                     // 677
        name: 'Oise',                                                  // 678
        regionId: '22',                                                // 679
        websites: {                                                    // 680
            Apec: '60'                                                 // 681
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 684
        _id: '61',                                                     // 685
        name: 'Orne',                                                  // 686
        regionId: '25',                                                // 687
        websites: {                                                    // 688
            Apec: '61'                                                 // 689
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 692
        _id: '62',                                                     // 693
        name: 'Pas de Calais',                                         // 694
        regionId: '31',                                                // 695
        websites: {                                                    // 696
            Apec: '62'                                                 // 697
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 700
        _id: '63',                                                     // 701
        name: 'Puy de Dôme',                                           // 702
        regionId: '83',                                                // 703
        websites: {                                                    // 704
            Apec: '63'                                                 // 705
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 708
        _id: '64',                                                     // 709
        name: 'Pyrénées Atlantiques',                                  // 710
        regionId: '72',                                                // 711
        websites: {                                                    // 712
            Apec: '64'                                                 // 713
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 716
        _id: '65',                                                     // 717
        name: 'Hautes Pyrénées',                                       // 718
        regionId: '73',                                                // 719
        websites: {                                                    // 720
            Apec: '65'                                                 // 721
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 724
        _id: '66',                                                     // 725
        name: 'Pyrénées Orientales',                                   // 726
        regionId: '91',                                                // 727
        websites: {                                                    // 728
            Apec: '66'                                                 // 729
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 732
        _id: '67',                                                     // 733
        name: 'Bas Rhin',                                              // 734
        regionId: '42',                                                // 735
        websites: {                                                    // 736
            Apec: '67'                                                 // 737
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 740
        _id: '68',                                                     // 741
        name: 'Haut Rhin',                                             // 742
        regionId: '42',                                                // 743
        websites: {                                                    // 744
            Apec: '68'                                                 // 745
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 748
        _id: '69',                                                     // 749
        name: 'Rhône',                                                 // 750
        regionId: '82',                                                // 751
        websites: {                                                    // 752
            Apec: '69'                                                 // 753
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 756
        _id: '70',                                                     // 757
        name: 'Haute Saône',                                           // 758
        regionId: '43',                                                // 759
        websites: {                                                    // 760
            Apec: '70'                                                 // 761
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 764
        _id: '71',                                                     // 765
        name: 'Saône et Loire',                                        // 766
        regionId: '26',                                                // 767
        websites: {                                                    // 768
            Apec: '71'                                                 // 769
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 772
        _id: '72',                                                     // 773
        name: 'Sarthe',                                                // 774
        regionId: '52',                                                // 775
        websites: {                                                    // 776
            Apec: '72'                                                 // 777
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 780
        _id: '73',                                                     // 781
        name: 'Savoie',                                                // 782
        regionId: '82',                                                // 783
        websites: {                                                    // 784
            Apec: '73'                                                 // 785
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 788
        _id: '74',                                                     // 789
        name: 'Haute Savoie',                                          // 790
        regionId: '82',                                                // 791
        websites: {                                                    // 792
            Apec: '74'                                                 // 793
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 796
        _id: '75',                                                     // 797
        name: 'Paris',                                                 // 798
        regionId: '11',                                                // 799
        websites: {                                                    // 800
            Apec: '75'                                                 // 801
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 804
        _id: '76',                                                     // 805
        name: 'Seine Maritime',                                        // 806
        regionId: '23',                                                // 807
        websites: {                                                    // 808
            Apec: '76'                                                 // 809
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 812
        _id: '77',                                                     // 813
        name: 'Seine et Marne',                                        // 814
        regionId: '11',                                                // 815
        websites: {                                                    // 816
            Apec: '77'                                                 // 817
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 820
        _id: '78',                                                     // 821
        name: 'Yvelines',                                              // 822
        regionId: '11',                                                // 823
        websites: {                                                    // 824
            Apec: '78'                                                 // 825
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 828
        _id: '79',                                                     // 829
        name: 'Deux Sèvres',                                           // 830
        regionId: '54',                                                // 831
        websites: {                                                    // 832
            Apec: '79'                                                 // 833
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 836
        _id: '80',                                                     // 837
        name: 'Somme',                                                 // 838
        regionId: '22',                                                // 839
        websites: {                                                    // 840
            Apec: '80'                                                 // 841
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 844
        _id: '81',                                                     // 845
        name: 'Tarn',                                                  // 846
        regionId: '73',                                                // 847
        websites: {                                                    // 848
            Apec: '81'                                                 // 849
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 852
        _id: '82',                                                     // 853
        name: 'Tarn et Garonne',                                       // 854
        regionId: '73',                                                // 855
        websites: {                                                    // 856
            Apec: '82'                                                 // 857
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 860
        _id: '83',                                                     // 861
        name: 'Var',                                                   // 862
        regionId: '93',                                                // 863
        websites: {                                                    // 864
            Apec: '83'                                                 // 865
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 868
        _id: '84',                                                     // 869
        name: 'Vaucluse',                                              // 870
        regionId: '93',                                                // 871
        websites: {                                                    // 872
            Apec: '84'                                                 // 873
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 876
        _id: '85',                                                     // 877
        name: 'Vendée',                                                // 878
        regionId: '52',                                                // 879
        websites: {                                                    // 880
            Apec: '85'                                                 // 881
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 884
        _id: '86',                                                     // 885
        name: 'Vienne',                                                // 886
        regionId: '54',                                                // 887
        websites: {                                                    // 888
            Apec: '86'                                                 // 889
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 892
        _id: '87',                                                     // 893
        name: 'Haute Vienne',                                          // 894
        regionId: '74',                                                // 895
        websites: {                                                    // 896
            Apec: '87'                                                 // 897
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 900
        _id: '88',                                                     // 901
        name: 'Vosges',                                                // 902
        regionId: '41',                                                // 903
        websites: {                                                    // 904
            Apec: '88'                                                 // 905
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 908
        _id: '89',                                                     // 909
        name: 'Yonne',                                                 // 910
        regionId: '26',                                                // 911
        websites: {                                                    // 912
            Apec: '89'                                                 // 913
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 916
        _id: '90',                                                     // 917
        name: 'Territoire de Belfort',                                 // 918
        regionId: '43',                                                // 919
        websites: {                                                    // 920
            Apec: '90'                                                 // 921
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 924
        _id: '91',                                                     // 925
        name: 'Essonne',                                               // 926
        regionId: '11',                                                // 927
        websites: {                                                    // 928
            Apec: '91'                                                 // 929
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 932
        _id: '92',                                                     // 933
        name: 'Hauts de Seine',                                        // 934
        regionId: '11',                                                // 935
        websites: {                                                    // 936
            Apec: '92'                                                 // 937
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 940
        _id: '93',                                                     // 941
        name: 'Seine Saint Denis',                                     // 942
        regionId: '11',                                                // 943
        websites: {                                                    // 944
            Apec: '93'                                                 // 945
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 948
        _id: '94',                                                     // 949
        name: 'Val de Marne',                                          // 950
        regionId: '11',                                                // 951
        websites: {                                                    // 952
            Apec: '94'                                                 // 953
        }                                                              //
    });                                                                //
    Departements.insert({                                              // 956
        _id: '95',                                                     // 957
        name: 'Val d\'Oise',                                           // 958
        regionId: '11',                                                // 959
        websites: {                                                    // 960
            Apec: '95'                                                 // 961
        }                                                              //
    });                                                                //
    /*Departements.insert({                                            //
        _id: '971',                                                    //
        name: 'Guadeloupe',                                            //
        regionId: '01',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Departements.insert({                                              //
        _id: '972',                                                    //
        name: 'Martinique',                                            //
        regionId: '02',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Departements.insert({                                              //
        _id: '973',                                                    //
        name: 'Guyane',                                                //
        regionId: '03',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Departements.insert({                                              //
        _id: '974',                                                    //
        name: 'La Réunion',                                            //
        regionId: '04',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });                                                                //
    Departements.insert({                                              //
        _id: '976',                                                    //
        name: 'Mayotte',                                               //
        regionId: '06',                                                //
        websites: {                                                    //
            Apec: ''                                                   //
        }                                                              //
    });*/                                                              //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures_dep_reg.js.map
