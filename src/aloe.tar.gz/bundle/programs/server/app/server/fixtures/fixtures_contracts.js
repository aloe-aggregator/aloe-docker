(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures/fixtures_contracts.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Contracts.find({                                                   // 1
    name: 'CDI'                                                        // 2
}).count() === 0) {                                                    //
    Contracts.insert({                                                 // 4
        name: 'CDI',                                                   // 5
        websites: {                                                    // 6
            Keljob: ['CDI', 'Avis de concours'],                       // 7
            Monster: ['CDI', 'Titulaire-de-la-fonction-publique'],     // 8
            Remixjobs: ['CDI'],                                        // 9
            Apec: ['101888'], // CDI                                   // 10
            Indeed: ['CDI'],                                           // 11
            Cadremploi: ['CDI', 'Statutaire']                          // 12
        }                                                              //
    });                                                                //
}                                                                      //
if (Contracts.find({                                                   // 16
    name: 'CDD'                                                        // 17
}).count() === 0) {                                                    //
    Contracts.insert({                                                 // 19
        name: 'CDD',                                                   // 20
        websites: {                                                    // 21
            Keljob: ['CDD', 'Intérim', 'Saisonnier', 'VIE'],           // 22
            Monster: ['Intérim-ou-CDD-ou-Mission'],                    // 23
            Remixjobs: ['CDD'],                                        // 24
            Apec: ['101887', '101889'], // CDD | Intérim               // 25
            Indeed: ['CDD'],                                           // 26
            Cadremploi: ['CDD / Intérim / VIE']                        // 27
        }                                                              //
    });                                                                //
}                                                                      //
if (Contracts.find({                                                   // 31
    name: 'Stage'                                                      // 32
}).count() === 0) {                                                    //
    Contracts.insert({                                                 // 34
        name: 'Stage',                                                 // 35
        websites: {                                                    // 36
            Keljob: ['Stage'],                                         // 37
            Monster: ['Stage-Apprentissage-Alternance'],               // 38
            Indeed: ['Stage'],                                         // 39
            Remixjobs: ['Stage']                                       // 40
        }                                                              //
    });                                                                //
}                                                                      //
if (Contracts.find({                                                   // 44
    name: 'Apprentissage'                                              // 45
}).count() === 0) {                                                    //
    Contracts.insert({                                                 // 47
        name: 'Apprentissage',                                         // 48
        websites: {                                                    // 49
            Keljob: ['Apprentissage/Alternance'],                      // 50
            Indeed: ['Apprentissage / Alternance'],                    // 51
            Monster: ['Stage-Apprentissage-Alternance']                // 52
        }                                                              //
    });                                                                //
}                                                                      //
if (Contracts.find({                                                   // 56
    name: 'Freelance'                                                  // 57
}).count() === 0) {                                                    //
    Contracts.insert({                                                 // 59
        name: 'Freelance',                                             // 60
        websites: {                                                    // 61
            Keljob: ['Indépendant / Freelance / Autoentrepreneur', 'Franchisé'],
            Monster: ['Indépendant-Freelance-Saisonnier-Franchise'],   // 63
            Remixjobs: ['Freelance'],                                  // 64
            Indeed: ['Freelance / Indépendant'],                       // 65
            Cadremploi: ['Indépendant / Freelance', 'Franchises']      // 66
        }                                                              //
    });                                                                //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures_contracts.js.map
