(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures/fixtures_offers_raw.js                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
	if (OffersRaw.find().count() === 0) {                                 // 2
		//Meteor.call('search', 'ingéniEUr JAVA', 'ChIJD7fiBh9u5kcRYJSMaMOCCwQ', null, null, null, ['Keljob', 'Remixjobs'], "CHAINE_UID");
		//Meteor.call('search', 'boulanger', 'ChIJD7fiBh9u5kcRYJSMaMOCCwQ', null, null, null, ['Apec', 'Cadremploi', 'Indeed', 'Keljob', 'Remixjobs', 'Monster'], "CHAINE_UID");
		//Meteor.call('search', 'ingéniEUr JAVA', 'ChIJD7fiBh9u5kcRYJSMaMOCCwQ', null, null, null, ['Apec', 'Cadremploi', 'Indeed', 'Keljob', 'Remixjobs', 'Monster'], null);
		//Meteor.call('search', 'boulanger', 'ChIJD7fiBh9u5kcRYJSMaMOCCwQ', null, null, null, ['Apec', 'Cadremploi', 'Indeed', 'Keljob', 'Remixjobs', 'Monster'], null);
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures_offers_raw.js.map
