(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// List of website (with details) processed atm                        //
Meteor.publish('websites', function () {                               // 2
	return Websites.find();                                               // 3
});                                                                    //
                                                                       //
// List of contract's type and equivalence                             //
Meteor.publish('contracts', function () {                              // 7
	return Contracts.find();                                              // 8
});                                                                    //
                                                                       //
// List of errors catched by server to display to users                //
Meteor.publish('errors', function () {                                 // 12
	return Errors.find();                                                 // 13
});                                                                    //
                                                                       //
// ALOE Global statistics for each websites processed atm (number of offers found, number of offers read and number of redirection)
Meteor.publish('statistics', function () {                             // 17
	return Stats.find();                                                  // 18
});                                                                    //
                                                                       //
/**                                                                    //
 * List of offers filtered by criteria (keyword, location, contracts,...) and options (atm - only max number of offers to get)
 * @param  {Object} 	                                                  //
				[String]	keywords	:	Keywords' list	                                //
				String		locationId	:	Google PlaceId	                               //
				String		data		:	Date in Javascript full date string format	        //
				String		salary		:	Salary without currency symbol	                  //
				[String]	contracts	:	Name of type of contract's list	              //
				[String]	websites	:	Websites' list	                                //
 * @param  {Object} 	                                                  //
 *				Number		limit		:	Maximum number of displayed/searched offers	    //
 * @return [{Object}] 	[Offer]                                         //
 */                                                                    //
Meteor.publish('offers', function (criteria, options) {                // 34
	check(options, {                                                      // 35
		limit: Number                                                        // 36
	});                                                                   //
	return getOffers(criteria, options);                                  // 38
});                                                                    //
                                                                       //
/**                                                                    //
 * Details of an offer                                                 //
 * @param  {String} Id of wanted offer                                 //
 * @return {Object} Offer                                              //
 */                                                                    //
Meteor.publish('singleOffer', function (id) {                          // 46
	check(id, String);                                                    // 47
	return Offers.find(id);                                               // 48
	// return OffersRaw.find(id);                                         //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
