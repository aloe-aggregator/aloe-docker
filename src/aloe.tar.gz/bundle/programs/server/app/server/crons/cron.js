(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/crons/cron.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var dailyCacheUpdate = function () {                                   // 1
    Search = new Mongo.Collection(null);                               // 2
                                                                       //
    Offers.find({}).forEach(function (offer) {                         // 4
        var listKeywordsDate = [];                                     // 5
        s = Search.findOne({ locationId: offer.effectiveLocationId });
                                                                       //
        if (s === undefined) {                                         // 8
            _.map(offer.keywords, function (kw) {                      // 9
                listKeywordsDate.push({ keyword: kw, dateScrap: offer.dateScrap });
            });                                                        //
                                                                       //
            Search.insert({                                            // 13
                locationId: offer.effectiveLocationId,                 // 14
                keywordsDate: listKeywordsDate                         // 15
            });                                                        //
        } else {                                                       //
            _.map(offer.keywords, function (kw) {                      // 18
                keywordDate = _.findWhere(s.keywordsDate, { keyword: kw });
                                                                       //
                if (keywordDate === undefined) {                       // 21
                    Search.update({ locationId: offer.effectiveLocationId }, { $set: { keywordsDate: _.union(s.keywordsDate, [{ keyword: kw, dateScrap: offer.dateScrap }]) } });
                } else {                                               //
                    if (offer.dateScrap > keywordDate.dateScrap) {     // 24
                        _.map(s.keywordsDate, function (kwDt) {        // 25
                            if (kwDt.keyword === kw) {                 // 26
                                kwDt.dateScrap = offer.dateScrap;      // 27
                            }                                          //
                        });                                            //
                                                                       //
                        Search.update({ locationId: offer.effectiveLocationId }, { $set: { keywordsDate: s.keywordsDate } });
                    }                                                  //
                }                                                      //
            });                                                        //
        }                                                              //
    });                                                                //
                                                                       //
    Search.find({}).forEach(function (search) {                        // 38
        var listWebsites = [];                                         // 39
                                                                       //
        _.map(search.keywordsDate, function (kwDt) {                   // 41
            Websites.find({}).forEach(function (ws) {                  // 42
                var threshold = getThreshold(ws._id);                  // 43
                                                                       //
                var dateThresholdMin = new Date();                     // 45
                var dateThresholdMax = new Date();                     // 46
                dateThresholdMin.setDate(dateThresholdMin.getDate() - threshold);
                dateThresholdMax.setDate(dateThresholdMin.getDate() - threshold + parseInt(Meteor.settings.cron.intervalDays));
                if (kwDt.dateScrap > dateThresholdMin && kwDt.dateScrap < dateThresholdMax) {
                    listWebsites.push(ws.name);                        // 50
                }                                                      //
            });                                                        //
                                                                       //
            if (listWebsites.length > 0) {                             // 54
                Meteor.call('search', kwDt.keyword, search.locationId, null, null, listWebsites, 'cron_daily');
            }                                                          //
        });                                                            //
    });                                                                //
                                                                       //
    Errors.remove({ userId: 'cron_daily' });                           // 60
    Search.remove({});                                                 // 61
};                                                                     //
                                                                       //
var clearLocationCache = function () {                                 // 64
    clearLocationScrap();                                              // 65
    clearLocationScale();                                              // 66
};                                                                     //
                                                                       //
var event = new Object();                                              // 69
event[Meteor.settings.cron.dbClearOffersResidualData] = clearOffersResidualData;
event[Meteor.settings.cron.dbClearLocation] = clearLocationCache;      // 71
event[Meteor.settings.cron.dailyCacheUpdate] = dailyCacheUpdate;       // 72
                                                                       //
new Meteor.Cron({                                                      // 74
    events: event                                                      // 75
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cron.js.map
