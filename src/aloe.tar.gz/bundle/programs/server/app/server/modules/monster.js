(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/monster.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchMonster = function (search, userId) {                            // 1
    var website = Websites.findOne({                                   // 2
        name: 'Monster'                                                // 3
    });                                                                //
                                                                       //
    // CSS Selectors                                                   //
    var selectors = getSelectors(website.name);                        // 7
                                                                       //
    // Parameters initialization                                       //
    var options = initParamsMonster(search);                           // 10
                                                                       //
    // URL build                                                       //
    var link = 'http://emploi.monster.fr/recherche/';                  // 13
                                                                       //
    // Date difference                                                 //
    var now = new Date();                                              // 16
    if (search.datePub != null) {                                      // 17
        var dayDiff = getDayGap(search.datePub, now, 'd');             // 18
    } else {                                                           //
        var dayDiff = Infinity;                                        // 20
    }                                                                  //
                                                                       //
    // Contracts                                                       //
    /*if (search.contracts != null) {                                  //
        var linkContracts = '';                                        //
        var linkContractsAdd = '';                                     //
         _.map(search.contracts, function(contract) {                  //
            contracts = Contracts.findOne({                            //
                name: contract                                         //
            }).websites.Monster;                                       //
             _.map(contracts, function(ct) {                           //
                linkContracts += ct.replace('é', '%C3%A9') + '+';      //
                linkContractsAdd += '8';                               //
            });                                                        //
        });                                                            //
        linkContracts = linkContracts.substring(0, linkContracts.length - 1) + '_' + linkContractsAdd;
        link += linkContracts;                                         //
    }*/                                                                //
                                                                       //
    var offersNb = 0;                                                  // 42
    var offersNbSucces = 0;                                            // 43
                                                                       //
    var isLastPage = false;                                            // 45
    var nbOffreEnCours = 0;                                            // 46
                                                                       //
    do {                                                               // 48
        try {                                                          // 49
            // Scrap start                                             //
            var result = Meteor.http.get(link, options);               // 51
                                                                       //
            if (result.statusCode < 200 || result.statusCode >= 300) {
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'statusCode = ' + result.statusCode + ' | URL = ' + url + ' | Options = ' + JSON.stringify(options));
                return;                                                // 55
            }                                                          //
        } catch (e) {                                                  //
            Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + url + ' | Options = ' + JSON.stringify(options));
            return;                                                    // 59
        }                                                              //
                                                                       //
        var $ = cheerio.load(result.content);                          // 62
                                                                       //
        var nbOffre = $('.page-title').first().text().trim().split(" ")[0];
                                                                       //
        if (Match.test(parseInt(nbOffre, 10), Match.Integer)) {        // 66
            nbOffre = parseInt(nbOffre, 10);                           // 67
                                                                       //
            $(selectors.offerItem).each(function (index, el) {         // 69
                /*$(this).find(selectors.date).find('span').remove();  //
                var datePub = removeUnusedCar($(this).find(selectors.date).text());
                var regexDatePub = new RegExp('Il y a \\d{1,3} jours');
                 if (datePub == 'Aujourd\'hui') {                      //
                    datePub = new Date();                              //
                } else if (regexDatePub.test(datePub)) {               //
                    datePub = backToPastDay(datePub.substring(7, datePub.length - 6));
                } else {                                               //
                    datePub = null;                                    //
                }*/                                                    //
                                                                       //
                date = $(this).find("div.postedDate time[itemprop='datePosted']").attr('datetime');
                datePub = new Date(date);                              // 83
                                                                       //
                // If the date is valid with the datePub parameter     //
                if (search.datePub === null || datePub === null || dayDiff >= getDayGap(datePub, now, 'd')) {
                    var url = $(this).find(selectors.offerLink).attr('href');
                    offersNb++;                                        // 88
                                                                       //
                    // Offer scrap start                               //
                    try {                                              // 91
                        var page = Meteor.http.get(url);               // 92
                                                                       //
                        if (page.statusCode >= 200 && page.statusCode < 300) {
                            var offer = new Object();                  // 95
                            var description = new Object();            // 96
                                                                       //
                            offer.search = search;                     // 98
                            offer.websites = [{                        // 99
                                website: website._id,                  // 100
                                url: url                               // 101
                            }];                                        //
                                                                       //
                            $$ = cheerio.load(page.content);           // 104
                                                                       //
                            offer.dateScrap = new Date();              // 106
                                                                       //
                            offer.salary = $$(selectors.salary).text(); //
                            if (offer.salary == '') {                  // 109
                                offer.salary = null;                   // 110
                            }                                          //
                                                                       //
                            offer.datePub = datePub;                   // 113
                                                                       //
                            offer.position = $(this).find(selectors.position).text();
                            offer.location = $(this).find(selectors.location).text();
                            offer.company = $(this).find(selectors.company).text();
                                                                       //
                            // Contract                                //
                            if ($$("dt:contains('Type de poste')").length != 0) {
                                contract = $$("dt:contains('Type de poste')").next();
                                offer.contractDisplayed = '';          // 122
                                do {                                   // 123
                                    offer.contractDisplayed += contract.find('span').text() + ',';
                                    contract = contract.next();        // 125
                                } while (contract.is('dd'));           //
                                offer.contractDisplayed = offer.contractDisplayed.substring(0, offer.contractDisplayed.length - 1);
                            } else if ($$('span[itemprop="employmentType"]').text() != "") {
                                offer.contractDisplayed = $$('span[itemprop="employmentType"]').text();
                            } else {                                   //
                                offer.contractDisplayed = null;        // 131
                            }                                          //
                            offer.contractDisplayed = removeUnusedCar(offer.contractDisplayed);
                            offer.contractEquivalence = contractScrapToAloe(offer.contractDisplayed, website.name);
                                                                       //
                            var description = new Object();            // 136
                            description.small = getSmallDescription($(this).find(selectors.descrSmall).text());
                                                                       //
                            var descrLarge = "span#TrackingJobBody";   // 139
                                                                       //
                            if ($$(descrLarge).text() == "") {         // 141
                                descrLarge = '.jobview-section';       // 142
                            } else {                                   //
                                $$(descrLarge).remove('img');          // 144
                            }                                          //
                                                                       //
                            description.large = removeUnusedCar($$(descrLarge).html());
                            offer.description = description;           // 148
                                                                       //
                            insertOffersRaw(offer);                    // 150
                            offersNbSucces++;                          // 151
                        } else {                                       //
                            Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'statusCode = ' + page.statusCode + ' | URL = ' + url);
                        }                                              //
                    } catch (e) {                                      //
                        Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + url);
                    }                                                  //
                }                                                      //
            });                                                        //
                                                                       //
            nbOffreEnCours += 25;                                      // 161
            if (nbOffreEnCours >= nbOffre) {                           // 162
                isLastPage = true;                                     // 163
            } else {                                                   //
                options.params.page++;                                 // 165
            }                                                          //
            // Update isLastPage and page params                       //
            /*if ($('div.pagingWrapper').length != 0) {                //
                if ($('div.pagingWrapper > div.paging > ul > .active').next().is('li')) {
                    options.params.page++;                             //
                } else {                                               //
                    isLastPage = true;                                 //
                }                                                      //
            } else {                                                   //
                isLastPage = true;                                     //
            }*/                                                        //
        } else {                                                       //
                isLastPage = true;                                     // 178
            }                                                          //
    } while (!isLastPage);                                             //
    if (offersNb !== offersNbSucces) {                                 // 181
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsMonster = function (search) {                                // 187
    var options = initParams();                                        // 188
    var params = new Object();                                         // 189
                                                                       //
    // Parameters Check & Set Request Parameters                       //
    // Keyword                                                         //
    params.q = spaceToHyphen(search.keyword);                          // 193
                                                                       //
    // Country France                                                  //
    params.cy = 'fr';                                                  // 196
                                                                       //
    // Location                                                        //
    // Request on Department ? -> Search on Region                     //
    // Department unavailable on monster                               //
    if (search.locationId != null) {                                   // 201
        if (search.location.typeArea === 'region' || search.location.typeArea === 'department') {
            params.where = 'Région:' + spaceToHyphen(search.location.region);
        } else if (search.location.typeArea === 'city') {              //
            params.where = search.location.city;                       // 205
        }                                                              //
    }                                                                  //
                                                                       //
    // DatePub                                                         //
    /*var now = new Date();                                            //
    if (search.datePub != null) {                                      //
        var dayDiff = getDayGap(search.datePub, now, 'd');             //
        if (dayDiff < 1) {                                             //
            params.tm = 'Aujourd\'hui';                                //
        } else if (dayDiff < 2) {                                      //
            params.tm = '2-derniers-jours';                            //
        } else if (dayDiff < 3) {                                      //
            params.tm = '3-derniers-jours';                            //
        } else if (dayDiff < 7) {                                      //
            params.tm = 'Les-7-derniers-jours';                        //
        } else if (dayDiff < 14) {                                     //
            params.tm = 'Les-14-derniers-jours';                       //
        } else if (dayDiff < 30) {                                     //
            params.tm = '30-derniers-jours';                           //
        }                                                              //
    }*/                                                                //
                                                                       //
    //Default                                                          //
    //params.rad = '20-km';                                            //
                                                                       //
    var headers = new Object();                                        // 231
    headers = {                                                        // 232
        "User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:43.0) Gecko/20100101 Firefox/43.0'
    };                                                                 //
                                                                       //
    //Page                                                             //
    params.page = 1;                                                   // 237
                                                                       //
    options.params = params;                                           // 239
    options.headers = headers;                                         // 240
                                                                       //
    return options;                                                    // 242
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=monster.js.map
