(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/indeed.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchIndeed = function (search, userId) {                             // 1
    var website = Websites.findOne({                                   // 2
        name: 'Indeed'                                                 // 3
    });                                                                //
                                                                       //
    var idContracts = { 'CDI': 'permanent', 'CDD': 'contract', 'Stage': 'internship', 'Apprentissage': 'apprenticeship', 'Freelance': 'subcontract' };
    var arrayContractEquivalence = { 'CDI': 'CDI', 'CDD': 'CDD', 'Intérim': 'CDD', 'Stage': 'Stage', 'Apprentissage / Alternance': 'Apprentissage', 'Freelance / Indépendant': 'Freelance' };
                                                                       //
    var contracts = [];                                                // 9
    _.map(search.contracts, function (c) {                             // 10
        contracts.push(idContracts[c]);                                // 11
    });                                                                //
                                                                       //
    if (contracts.length === 0) {                                      // 14
        contracts.push('');                                            // 15
    }                                                                  //
                                                                       //
    var nbOfferPerPage = 25;                                           // 18
    var options = initParamsIndeed(search, nbOfferPerPage);            // 19
    var offersNb = 0;                                                  // 20
    var offersNbSucces = 0;                                            // 21
                                                                       //
    var link = 'http://api.indeed.com/ads/apisearch';                  // 23
                                                                       //
    var isLastPage = false;                                            // 25
    options.params.start = 0;                                          // 26
                                                                       //
    _.map(contracts, function (jobType) {                              // 28
        options.params.jt = jobType;                                   // 29
        do {                                                           // 30
            try {                                                      // 31
                var result = Meteor.http.get(link, options);           // 32
                                                                       //
                if (result.statusCode < 200 || result.statusCode >= 300) {
                    Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'StatusCode = ' + e.response.statusCode + ' | URL : ' + url + ' | Options = ' + JSON.stringify(options));
                    return;                                            // 36
                }                                                      //
            } catch (e) {                                              //
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'StatusCode = ' + e.response.statusCode + ' | URL : ' + url + ' | Options = ' + JSON.stringify(options));
                return;                                                // 40
            }                                                          //
                                                                       //
            var content = JSON.parse(result.content);                  // 43
            _.map(content.results, function (o) {                      // 44
                offersNb++;                                            // 45
                                                                       //
                try {                                                  // 47
                    var res = Meteor.http.get(o.url, initParams());    // 48
                                                                       //
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        var offer = new Object();                      // 51
                        var $ = cheerio.load(res.content);             // 52
                                                                       //
                        offer.search = search;                         // 54
                        offer.websites = [{                            // 55
                            website: website._id,                      // 56
                            url: o.url                                 // 57
                        }];                                            //
                        offer.dateScrap = new Date();                  // 59
                        offer.datePub = new Date(o.date);              // 60
                        offer.position = o.jobtitle;                   // 61
                        offer.location = o.formattedLocationFull;      // 62
                        offer.company = o.company;                     // 63
                                                                       //
                        offer.description = {                          // 65
                            small: o.snippet,                          // 66
                            large: $('#job_summary').html()            // 67
                        };                                             //
                                                                       //
                        var headerOffer = $('#job_header').text();     // 70
                        offer.contractDisplayed = null;                // 71
                        offer.contractEquivalence = null;              // 72
                                                                       //
                        _.map(arrayContractEquivalence, function (value, key) {
                            if (headerOffer.indexOf(key) > -1) {       // 75
                                offer.contractDisplayed = key;         // 76
                                offer.contractEquivalence = value;     // 77
                            }                                          //
                        });                                            //
                                                                       //
                        insertOffersRaw(offer);                        // 81
                        offersNbSucces++;                              // 82
                    } else {                                           //
                        Meteor.call('insertLog', userId, ['public.error.scrapGeneral', website.name], 'StatusCode = ' + res.statusCode + ' | URL = ' + link + ' | Options = ' + JSON.stringify(initParams()));
                        return;                                        // 85
                    }                                                  //
                } catch (e) {                                          //
                    Meteor.call('insertLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + link + ' | Options = ' + JSON.stringify(options));
                    return;                                            // 89
                }                                                      //
            });                                                        //
                                                                       //
            if (options.params.start + nbOfferPerPage > content.totalResults) {
                isLastPage = true;                                     // 94
            } else {                                                   //
                options.params.start += nbOfferPerPage;                // 96
            }                                                          //
        } while (!isLastPage);                                         //
    });                                                                //
                                                                       //
    if (offersNb !== offersNbSucces) {                                 // 101
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsIndeed = function (search, nbMax) {                          // 107
    var options = initParams();                                        // 108
    var params = new Object();                                         // 109
                                                                       //
    params.publisher = 868274777654456;                                // 111
    params.v = 2;                                                      // 112
    params.format = 'json';                                            // 113
    params.q = search.keyword;                                         // 114
                                                                       //
    if (search.locationId != null) {                                   // 116
        if (search.location.typeArea === 'region') {                   // 117
            params.l = search.location.region;                         // 118
        } else if (search.location.typeArea === 'department') {        //
            params.l = search.location.department;                     // 120
        } else if (search.location.typeArea === 'city') {              //
            params.l = search.location.city;                           // 122
        }                                                              //
    }                                                                  //
                                                                       //
    params.sort = 'date';                                              // 126
    params.limit = nbMax;                                              // 127
    params.userip = '1.2.3.4';                                         // 128
    params.useragent = 'Mozilla//4.0(Firefox)';                        // 129
    if (search.datePub != null) {                                      // 130
        params.fromage = parseInt((new Date() - search.datePub) / (24 * 60 * 60 * 1000));
    }                                                                  //
    params.filter = 1;                                                 // 133
    params.co = 'fr';                                                  // 134
                                                                       //
    options.params = params;                                           // 136
                                                                       //
    return options;                                                    // 138
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=indeed.js.map
