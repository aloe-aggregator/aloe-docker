(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/keljob.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchKeljob = function (search, userId) {                             // 1
    var website = Websites.findOne({                                   // 2
        name: 'Keljob'                                                 // 3
    });                                                                //
                                                                       //
    // CSS Selectors                                                   //
    var selectors = getSelectors(website.name);                        // 7
    // Parameters initialisation                                       //
    var options = initParamsKeljob(search);                            // 9
                                                                       //
    // URL construction                                                //
    var link = website.url + 'recherche';                              // 12
                                                                       //
    // Date difference                                                 //
    var now = new Date();                                              // 15
    if (search.datePub != null) {                                      // 16
        var dayDiff = getDayGap(search.datePub, now, 'd');             // 17
    } else {                                                           //
        var dayDiff = Infinity;                                        // 19
    }                                                                  //
                                                                       //
    var offersNb = 0;                                                  // 22
    var offersNbSucces = 0;                                            // 23
                                                                       //
    var isLastPage = false;                                            // 25
    do {                                                               // 26
        try {                                                          // 27
            // Scrap start                                             //
            var result = Meteor.http.get(link, options);               // 29
                                                                       //
            if (result.statusCode < 200 || result.statusCode >= 300) {
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'statusCode = ' + result.statusCode + ' | URL = ' + link + ' | Options = ' + JSON.stringify(options));
                return;                                                // 33
            }                                                          //
        } catch (e) {                                                  //
            Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + link + ' | Options = ' + JSON.stringify(options));
            return;                                                    // 37
        }                                                              //
                                                                       //
        var $ = cheerio.load(result.content);                          // 40
                                                                       //
        if ($(selectors.offerItem).length != 0) {                      // 42
            // For each result on the page                             //
            $(selectors.offerItem + '> div').each(function () {        // 44
                if ($(this).hasClass('search-offer')) {                // 45
                    var dateString = $(this).find(selectors.date).text();
                    var dateSplit = dateString.split('/');             // 47
                    var datePub = new Date(dateSplit[2], dateSplit[1] - 1, dateSplit[0]);
                                                                       //
                    // If the date is valid with the datePub parameter
                    if (search.datePub === null || dayDiff >= getDayGap(datePub, now, 'd')) {
                                                                       //
                        var url = website.url.substring(0, website.url.length - 1) + $(this).find(selectors.offerLink).attr('href');
                        offersNb++;                                    // 54
                                                                       //
                        // Offer scrap start                           //
                        try {                                          // 57
                            var page = Meteor.http.get(url);           // 58
                                                                       //
                            if (page.statusCode >= 200 && page.statusCode < 300) {
                                var offer = new Object();              // 61
                                offer.search = search;                 // 62
                                offer.websites = [{                    // 63
                                    website: website._id,              // 64
                                    url: url                           // 65
                                }];                                    //
                                                                       //
                                offer.datePub = datePub;               // 68
                                offer.dateScrap = new Date();          // 69
                                                                       //
                                offer.position = $(this).find(selectors.position).first().text().trim();
                                                                       //
                                offer.location = $(this).find(selectors.location).text();
                                                                       //
                                offer.company = $(this).find(selectors.company).text();
                                                                       //
                                offer.contractDisplayed = $(this).find(selectors.contract).text();
                                offer.contractEquivalence = contractScrapToAloe(offer.contractDisplayed, website.name);
                                                                       //
                                var description = new Object();        // 80
                                                                       //
                                description.small = getSmallDescription($(this).find(selectors.descrSmall).text());
                                $$ = cheerio.load(page.content);       // 83
                                                                       //
                                descritpionDom = $$(selectors.descrLarge).first().parent().parent();
                                descritpionDom.find('span').remove();  // 86
                                                                       //
                                var i = 1;                             // 88
                                descriptionLarge = '';                 // 89
                                while (true) {                         // 90
                                    if (descritpionDom.find('section:nth-child(' + i + ')').length !== 0) {
                                        descriptionLarge += descritpionDom.find('section:nth-child(' + i + ')').html();
                                        i++;                           // 93
                                    } else {                           //
                                        break;                         // 95
                                    }                                  //
                                }                                      //
                                                                       //
                                description.large = removeUnusedCar(descriptionLarge);
                                offer.description = description;       // 100
                                                                       //
                                // Insert OffersRaw + Statistics       //
                                insertOffersRaw(offer);                // 103
                                offersNbSucces++;                      // 104
                            } else {                                   //
                                Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'statusCode = ' + page.statusCode + ' | URL = ' + url);
                            }                                          //
                        } catch (e) {                                  //
                            Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + url);
                        }                                              //
                    }                                                  //
                }                                                      //
            });                                                        //
            // Pagination                                              //
            if ($('.pagination-centered').find('ul.pagination')) {     // 115
                if ($('ul.pagination > .current').next().is('li')) {   // 116
                    options.params.page = options.params.page + 1;     // 117
                } else {                                               //
                    isLastPage = true;                                 // 119
                }                                                      //
            } else {                                                   //
                isLastPage = true;                                     // 122
            }                                                          //
        } else {                                                       //
            isLastPage = true;                                         // 125
        }                                                              //
    } while (!isLastPage);                                             //
    if (offersNb !== offersNbSucces) {                                 // 129
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsKeljob = function (search) {                                 // 135
    var options = initParams();                                        // 136
    var params = new Object();                                         // 137
                                                                       //
    // Parameters Check & Set Request Parameters                       //
    // Keyword                                                         //
    params.q = search.keyword;                                         // 141
                                                                       //
    // Page                                                            //
    params.page = 1;                                                   // 144
                                                                       //
    // Location                                                        //
    if (search.locationId != null) {                                   // 147
        if (search.location.typeArea === 'region') {                   // 148
            params.l = search.location.region;                         // 149
        } else if (search.location.typeArea === 'department') {        //
            params.l = search.location.department;                     // 151
        } else if (search.location.typeArea === 'city') {              //
            params.l = search.location.city;                           // 153
        } else if (search.location.typeArea === 'subcity') {           //
            params.l = search.location.subcity;                        // 155
        }                                                              //
        params.lon = search.location.longitude;                        // 157
        params.lat = search.location.latitude;                         // 158
    }                                                                  //
                                                                       //
    // Contracts                                                       //
    if (search.contracts != null) {                                    // 162
        params.c = '';                                                 // 163
        _.map(search.contracts, function (ct) {                        // 164
            contracts = Contracts.findOne({                            // 165
                name: ct                                               // 166
            }).websites.Keljob;                                        //
            _.map(contracts, function (contract) {                     // 168
                params.c += contract + ',';                            // 169
            });                                                        //
        });                                                            //
        params.c = params.c.substring(0, params.c.length - 1);         // 172
    }                                                                  //
                                                                       //
    // DatePub                                                         //
    var now = new Date();                                              // 176
    if (search.datePub != null) {                                      // 177
        var dayDiff = getDayGap(search.datePub, now, 'd');             // 178
        if (dayDiff < 1) {                                             // 179
            params.d = '1d';                                           // 180
        } else if (dayDiff < 3) {                                      //
            params.d = '3d';                                           // 182
        } else if (dayDiff < 7) {                                      //
            params.d = '7d';                                           // 184
        } else if (dayDiff < 30) {                                     //
            params.d = '30d';                                          // 186
        }                                                              //
    }                                                                  //
                                                                       //
    options.params = params;                                           // 190
                                                                       //
    return options;                                                    // 192
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=keljob.js.map
