(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/remixjobs.js                                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchRemixjobs = function (search, userId) {                          // 1
    var months = ['janv', 'févr', 'mars', 'avr', 'mai', 'juin', 'juil', 'août', 'sept', 'oct', 'nov', 'déc'];
    var website = Websites.findOne({ name: 'Remixjobs' });             // 3
                                                                       //
    var selectors = getSelectors(website.name);                        // 5
    var options = initParamsRemixjobs(search);                         // 6
                                                                       //
    var link = website.url + options.location + 'Emploi-' + search.keyword;
    delete options.location;                                           // 9
                                                                       //
    var offersNb = 0;                                                  // 11
    var offersNbSucces = 0;                                            // 12
    var isLastPage = false;                                            // 13
    var page = 1;                                                      // 14
    do {                                                               // 15
        try {                                                          // 16
            var result = Meteor.http.get(link + '/' + page, options);  // 17
                                                                       //
            if (result.statusCode < 200 || result.statusCode >= 300) {
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'statusCode = ' + result.statusCode + ' | URL = ' + link + '/' + page + ' | Options = ' + JSON.stringify(options));
                return;                                                // 21
            }                                                          //
        } catch (e) {                                                  //
            Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + link + '/' + page + ' | Options = ' + JSON.stringify(options));
            return;                                                    // 25
        }                                                              //
                                                                       //
        var $ = cheerio.load(result.content);                          // 28
                                                                       //
        $(selectors.offerItem).each(function (index, el) {             // 30
            // get date of publication for each offer                  //
            var regexMin = new RegExp('minute(s)?$');                  // 32
            var regexDate = new RegExp('^\\d{1,2}\\s(\\w){3,4}\\.\\s\\d{4}$');
                                                                       //
            var dateStr = $(this).find(selectors.date).text();         // 35
                                                                       //
            if (dateStr === 'à l’instant' || regexMin.test(dateStr)) {
                var offerDate = new Date();                            // 38
            } else if (regexDate.test(dateStr)) {                      //
                var array = dateStr.split(' ');                        // 40
                var year = parseInt(array[2]);                         // 41
                var month = parseInt(months.indexOf(array[1].replace('.', '')));
                var day = parseInt(array[0]);                          // 43
                                                                       //
                var offerDate = new Date(year, month, day);            // 45
            } else {                                                   //
                // format 'n heures'                                   //
                var array = dateStr.split(' ');                        // 47
                var hour = array[0];                                   // 48
                var dateOffer = new Date();                            // 49
                                                                       //
                dateOffer.setHours(dateOffer.getHours() - parseInt(hour));
                offerDate = dateOffer;                                 // 52
            }                                                          //
                                                                       //
            // Stop 'each()' if offer is too old                       //
            if (search.datePub != null) {                              // 56
                if (offerDate < search.datePub) {                      // 57
                    isLastPage = true;                                 // 58
                    return false;                                      // 59
                }                                                      //
            }                                                          //
                                                                       //
            var offer = new Object();                                  // 63
            var offerLink = $(this).find(selectors.offerLink).attr('href');
            offerLink = website.url + offerLink.substr(1);             // 65
                                                                       //
            offersNb++;                                                // 67
            try {                                                      // 68
                var res = Meteor.http.get(offerLink);                  // 69
                                                                       //
                if (res.statusCode >= 200 && res.statusCode < 300) {   // 71
                    var $$ = cheerio.load(res.content);                // 72
                                                                       //
                    salaryStr = $$(selectors.salary).text();           // 74
                    if (salaryStr == 'Salaire non communiqué') {       // 75
                        offer.salary = null;                           // 76
                    } else {                                           //
                        if (search.salary !== null) {                  // 78
                            salaryHigh = salaryStr.substr(-3, 2);      // 79
                            salary = parseInt(salaryHigh + '000');     // 80
                                                                       //
                            if (salary < search.salary) {              // 82
                                return true; // Next loop              // 83
                            }                                          //
                        }                                              //
                                                                       //
                        offer.salary = salaryStr;                      // 87
                    }                                                  //
                                                                       //
                    offer.datePub = offerDate;                         // 90
                    offer.dateScrap = new Date();                      // 91
                    offer.search = search;                             // 92
                    offer.websites = [{                                // 93
                        website: website._id,                          // 94
                        url: offerLink                                 // 95
                    }];                                                //
                    offer.position = $(this).find(selectors.position).text();
                    offer.location = $(this).find(selectors.location).text();
                    offer.company = $(this).find(selectors.company).text();
                    offer.contractDisplayed = $(this).find(selectors.contract).text().trim();
                    offer.contractEquivalence = $(this).find(selectors.contract).text().trim();
                                                                       //
                    offer.description = {                              // 103
                        large: $$(selectors.descrLarge).html().trim(),
                        small: getSmallDescription($$(selectors.descrSmall).text().trim())
                    };                                                 //
                                                                       //
                    insertOffersRaw(offer);                            // 108
                    offersNbSucces++;                                  // 109
                } else {                                               //
                    Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'StatusCode = ' + res.statusCode);
                }                                                      //
            } catch (e) {                                              //
                Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + offerLink);
            }                                                          //
        });                                                            //
                                                                       //
        // Test if is the last page of results                         //
        if ($('div.pagination > a.current + a').hasClass('prev-link') || $('div.no-element-wrapper > a.no-element').length) {
            isLastPage = true;                                         // 120
        } else {                                                       //
            page++;                                                    // 122
        }                                                              //
    } while (!isLastPage);                                             //
    if (offersNb !== offersNbSucces) {                                 // 125
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsRemixjobs = function (search) {                              // 131
    var options = initParams();                                        // 132
    var params = new Object();                                         // 133
    var location = '';                                                 // 134
                                                                       //
    // Location                                                        //
    if (search.locationId != null) {                                   // 137
        params.lat = search.location.latitude.toFixed(2);              // 138
        params.lng = search.location.longitude.toFixed(2);             // 139
                                                                       //
        if (search.location.typeArea === 'region') {                   // 141
            location = search.location.region.replace(new RegExp('-', 'g'), ' ');
            params.dist = 200;                                         // 143
        } else if (search.location.typeArea === 'department') {        //
            location = search.location.department.replace(new RegExp('-', 'g'), ' ');
            params.dist = 100;                                         // 146
        } else if (search.location.typeArea === 'city') {              //
            location = search.location.city.replace(new RegExp('-', 'g'), ' ');
            params.dist = 50;                                          // 149
        } else if (search.location.typeArea === 'subcity') {           //
            location = search.location.subcity.replace(new RegExp('-', 'g'), ' ');
            params.dist = 50;                                          // 152
        }                                                              //
        location += ', France-';                                       // 154
    }                                                                  //
                                                                       //
    // Contract                                                        //
    if (search.contracts != null) {                                    // 158
        var indexApprentissage = search.contracts.indexOf('Apprentissage');
        if (indexApprentissage !== -1) {                               // 160
            search.contracts.splice(indexApprentissage, 1);            // 161
                                                                       //
            if (search.contracts.indexOf('CDD') === -1) {              // 163
                search.contracts.push('CDD');                          // 164
            }                                                          //
        }                                                              //
        params.contract = search.contracts.join();                     // 167
    }                                                                  //
                                                                       //
    options.params = params;                                           // 170
    options.location = location;                                       // 171
                                                                       //
    return options;                                                    // 173
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=remixjobs.js.map
