(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/general.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * insert an offer in offersRaw                                        //
 * @param  {OffersRaw} offer The offer                                 //
 */                                                                    //
insertOffersRaw = function (offer) {                                   // 5
    OffersRaw.insert(offer);                                           // 6
};                                                                     //
                                                                       //
/**                                                                    //
 * get a small description of an offer                                 //
 * the size of the description is defined in the settings.json         //
 * @param  {String} longDescription The description to cut             //
 * @return {String} The cut description                                //
 */                                                                    //
getSmallDescription = function (longDescription) {                     // 15
    charLimit = Meteor.settings.sizeOfferSmallDescription;             // 16
                                                                       //
    check(longDescription, String);                                    // 18
    check(charLimit, Number);                                          // 19
                                                                       //
    var returnString = '';                                             // 21
    if (longDescription.length > charLimit) {                          // 22
        longDescription = longDescription.substring(0, charLimit);     // 23
        if (longDescription.substring(longDescription.length - 3, longDescription.length).indexOf('.') != -1) {
            longDescription = longDescription.substring(0, longDescription.length - 3);
        }                                                              //
        returnString = longDescription.substring(0, charLimit) + ' ...';
    } else {                                                           //
        returnString = longDescription;                                // 29
    }                                                                  //
                                                                       //
    return returnString;                                               // 32
};                                                                     //
                                                                       //
/**                                                                    //
 * initialize general parameter to each modules for the scrap          //
 * the timeout is defined in the settings.json                         //
 * @return {Object} The object to send in the header of a post/get request
 */                                                                    //
initParams = function () {                                             // 40
    return {                                                           // 41
        timeout: Meteor.settings.timeout                               // 42
    };                                                                 //
};                                                                     //
                                                                       //
/**                                                                    //
 * get scrap selectors for a specified website                         //
 * @param  {String} websiteName The website to get selectors           //
 * @return {Object} An object which contains all scrap selectors for the website
 */                                                                    //
getSelectors = function (websiteName) {                                // 51
    if (websiteName == 'Remixjobs') {                                  // 52
        return {                                                       // 53
            offerItem: '.job-item',                                    // 54
            date: 'span.job-details-right',                            // 55
            offerLink: 'a.job-link',                                   // 56
            salary: 'ul.job-infos > li.paycheck',                      // 57
            position: 'a.job-link',                                    // 58
            location: 'a.workplace',                                   // 59
            company: 'a.company',                                      // 60
            contract: 'a.contract',                                    // 61
            descrLarge: 'div.job-description',                         // 62
            descrSmall: 'div.job-description'                          // 63
        };                                                             //
    } else if (websiteName == 'Keljob') {                              //
        return {                                                       // 66
            offerItem: '.job-results > div.row > div.columns',         // 67
            date: '.offre-date',                                       // 68
            offerLink: '.offre-title > a',                             // 69
            position: '.offre-title > a > span',                       // 70
            location: '.offre-location',                               // 71
            company: '.offre-company > a',                             // 72
            contract: '.offre-contracts',                              // 73
            descrLarge: '.job-paragraph',                              // 74
            descrSmall: '.job-description'                             // 75
        };                                                             //
    } else if (websiteName == 'Monster') {                             //
        return {                                                       // 78
            offerItem: 'section#resultsWrapper > .js_result_container',
            date: 'div.postedDate time[itemprop="datePosted"]',        // 80
            offerLink: 'div.jobTitle > h2 > a',                        // 81
            salary: 'span[itemprop="baseSalary"]',                     // 82
            position: 'div.jobTitle > h2 > a > span',                  // 83
            location: 'div.location > span[itemprop="name"]',          // 84
            company: 'div.company span[itemprop="name"]',              // 85
            descrSmall: 'div.preview'                                  // 86
        };                                                             //
    } else if (websiteName == 'Cadremploi') {                          //
        return {                                                       // 89
            offerItem: 'li[itemtype="http://schema.org/JobPosting"]',  // 90
            date: 'span[itemprop="datePosted"]',                       // 91
            offerLink: 'div.description-offre > a.h3',                 // 92
            position: 'span[itemprop="title"]',                        // 93
            location: 'span[itemprop="jobLocation"]',                  // 94
            company: 'a[itemprop="hiringOrganization"] > span',        // 95
            contract: 'span[itemprop="employmentType"]',               // 96
            descrLarge: 'div.job-offer__desc',                         // 97
            descrSmall: 'p[itemprop="description"]'                    // 98
        };                                                             //
    } else {                                                           //
        Meteor.call('insertLog', ['server.error.selectorsMissing', websiteName], ['server.error.selectorsExplanation']);
        return false;                                                  // 102
    }                                                                  //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=general.js.map
