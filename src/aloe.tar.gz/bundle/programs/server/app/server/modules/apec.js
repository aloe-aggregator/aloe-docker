(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/apec.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchApec = function (search, userId) {                               // 1
    var website = Websites.findOne({                                   // 2
        name: 'Apec'                                                   // 3
    });                                                                //
                                                                       //
    // Parameters initialisation                                       //
    var options = initParamsApec(search);                              // 7
                                                                       //
    var link = 'https://cadres.apec.fr/cms/webservices/rechercheOffre/ids';
    var offersNb = 0;                                                  // 10
    var offersNbSucces = 0;                                            // 11
                                                                       //
    var isLastPage = false;                                            // 13
    var dateStop = false;                                              // 14
    do {                                                               // 15
        try {                                                          // 16
            // Scrap start                                             //
            var result = Meteor.http.post(link, options);              // 18
                                                                       //
            if (result.statusCode < 200 || result.statusCode >= 300) {
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'statusCode = ' + result.statusCode + ' | URL = ' + link + ' | Options = ' + JSON.stringify(options));
                return;                                                // 22
            }                                                          //
        } catch (e) {                                                  //
            Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + link + ' | Options = ' + JSON.stringify(options));
            return;                                                    // 26
        }                                                              //
                                                                       //
        var data = result.data;                                        // 29
        _.map(data.resultats, function (offerUrl) {                    // 30
            if (dateStop !== true) {                                   // 31
                offersNb++;                                            // 32
                                                                       //
                // Offer scrap start                                   //
                try {                                                  // 35
                    var url = 'https://cadres.apec.fr/cms/webservices/' + offerUrl['@uriOffre'];
                    var pageOffer = Meteor.http.get(url);              // 37
                                                                       //
                    if (pageOffer.statusCode >= 200 && pageOffer.statusCode < 300) {
                        // Offer second page scrap                     //
                        try {                                          // 41
                            var url2 = 'https://cadres.apec.fr/cms/webservices/rechercheOffre';
                            var options2 = cloneObject(options);       // 43
                                                                       //
                            options2.data.motsCles = pageOffer.data.numeroOffre;
                            options2.data.pagination = {               // 46
                                startIndex: 0,                         // 47
                                range: 1                               // 48
                            };                                         //
                                                                       //
                            var pageOffer2 = Meteor.http.post(url2, options);
                                                                       //
                            if (pageOffer2.statusCode >= 200 && pageOffer2.statusCode < 300) {
                                var offerContent = pageOffer.data;     // 54
                                var offerContent2 = pageOffer2.data.resultats[0];
                                                                       //
                                // Stop the scrap if the date is after the date parameter of the search
                                if (search.datePub != null) {          // 58
                                    if (new Date(offerContent.datePublication).getTime() < search.datePub.getTime()) {
                                        offersNb--;                    // 60
                                        dateStop = true;               // 61
                                    }                                  //
                                }                                      //
                                                                       //
                                if (dateStop !== true) {               // 65
                                    // Set Offer                       //
                                    var offer = new Object();          // 67
                                    offer.search = search;             // 68
                                                                       //
                                    offer.dateScrap = new Date();      // 70
                                                                       //
                                    offer.websites = [{                // 72
                                        website: website._id,          // 73
                                        url: 'https://cadres.apec.fr/home/mes-offres/recherche-des-offres-demploi/liste-des-offres-demploi.html?motsCles=' + offerContent.numeroOffre
                                    }];                                //
                                                                       //
                                    offer.salary = offerContent.salaireMinimum + 'K - ' + offerContent.salaireMaximum + 'K';
                                    offer.datePub = new Date(offerContent.datePublication);
                                    offer.position = offerContent.intitule;
                                    offer.location = offerContent.lieuTexte;
                                    offer.company = offerContent2.nomCommercial;
                                    offer.contractDisplayed = contractScrapToAloe(String(offerContent.idNomTypeContrat), website.name);
                                    offer.contractEquivalence = offer.contractDisplayed;
                                    var description = new Object();    // 84
                                                                       //
                                    description.small = getSmallDescription(offerContent2.texteOffre);
                                    description.large = offerContent.texteHtml;
                                                                       //
                                    offer.description = description;   // 89
                                                                       //
                                    insertOffersRaw(offer);            // 91
                                    offersNbSucces++;                  // 92
                                }                                      //
                            } else {                                   //
                                Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'statusCode = ' + pageOffer2.statusCode + ' | URL2 = ' + url2);
                            }                                          //
                        } catch (e) {                                  //
                            Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL2 = ' + url2);
                        }                                              //
                    } else {                                           //
                        Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'statusCode = ' + pageOffer.statusCode + ' | URL = ' + url);
                    }                                                  //
                } catch (e) {                                          //
                    Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + url);
                }                                                      //
            }                                                          //
        });                                                            //
                                                                       //
        // Update var isLastPage and page                              //
        nbResults = options.data.pagination.startIndex + options.data.pagination.range;
        if (data.totalCount < nbResults || dateStop === true) {        // 111
            isLastPage = true;                                         // 112
        } else {                                                       //
            options.data.pagination.startIndex += options.data.pagination.range;
        }                                                              //
    } while (!isLastPage);                                             //
    if (offersNb !== offersNbSucces) {                                 // 118
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsApec = function (search) {                                   // 124
    var options = initParams();                                        // 125
    var params = new Object();                                         // 126
                                                                       //
    //Forced params                                                    //
    params.activeFiltre = true;                                        // 129
    params.fonctions = [];                                             // 130
    params.typesConvention = [];                                       // 131
    params.niveauxExperience = [];                                     // 132
    params.secteursActivite = [];                                      // 133
    params.typeClient = "CADRE";                                       // 134
                                                                       //
    // Contracts                                                       //
    params.typesContrat = [];                                          // 137
    if (search.contracts != null) {                                    // 138
        _.map(search.contracts, function (ct) {                        // 139
            contract = Contracts.findOne({                             // 140
                name: ct                                               // 141
            });                                                        //
            if (contract.websites.Apec != null) {                      // 143
                _.map(contract.websites.Apec, function (ctApec) {      // 144
                    params.typesContrat.push(parseInt(ctApec));        // 145
                });                                                    //
            }                                                          //
        });                                                            //
    }                                                                  //
                                                                       //
    // Sorts                                                           //
    params.sorts = [{                                                  // 152
        type: "DATE",                                                  // 153
        direction: "DESCENDING"                                        // 154
    }];                                                                //
                                                                       //
    // Pagination                                                      //
    params.pagination = {                                              // 158
        startIndex: 0,                                                 // 159
        range: 20                                                      // 160
    };                                                                 //
                                                                       //
    // Place                                                           //
    params.lieux = [];                                                 // 164
    if (search.locationId != null) {                                   // 165
        if (search.location.typeArea === 'region') {                   // 166
            params.lieux.push(parseInt(Regions.findOne({               // 167
                name: search.location.region.replace(new RegExp('-', 'g'), ' ')
            }).websites.Apec));                                        //
        } else {                                                       //
            params.lieux.push(parseInt(Departements.findOne({          // 171
                name: search.location.department.replace(new RegExp('-', 'g'), ' ')
            }).websites.Apec));                                        //
        }                                                              //
    } else {                                                           //
        // France is 799                                               //
        params.lieux.push(799);                                        // 177
    }                                                                  //
                                                                       //
    // Keyword                                                         //
    params.motsCles = search.keyword;                                  // 181
                                                                       //
    options.data = params;                                             // 183
    options.headers = {                                                // 184
        'content-type': 'application/json'                             // 185
    };                                                                 //
                                                                       //
    return options;                                                    // 188
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=apec.js.map
