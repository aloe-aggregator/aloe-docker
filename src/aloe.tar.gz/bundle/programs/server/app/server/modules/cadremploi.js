(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/modules/cadremploi.js                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
searchCadremploi = function (search, userId) {                         // 1
    var iconv = Meteor.npmRequire('iconv-lite');                       // 2
    var website = Websites.findOne({                                   // 3
        name: 'Cadremploi'                                             // 4
    });                                                                //
                                                                       //
    var selectors = getSelectors(website.name);                        // 7
    var options = initParamsCadremploi(search);                        // 8
                                                                       //
    var link = 'http://www.cadremploi.fr/emploi/fr.cadremploi.publi.page.recherche_offres.RechercheOffresCtrl?';
    var linkListOffersOrigin = 'http://www.cadremploi.fr/emploi/liste_offres';
    var offersNb = 0;                                                  // 12
    var offersNbSucces = 0;                                            // 13
                                                                       //
    var isLastPage = false;                                            // 15
    var page = 1;                                                      // 16
    do {                                                               // 17
        try {                                                          // 18
            // Scrap start                                             //
            var r = Meteor.http.get(link, options);                    // 20
                                                                       //
            var $$$ = cheerio.load(r.content);                         // 22
                                                                       //
            if (page == 1) {                                           // 24
                linkListOffers = linkListOffersOrigin + $$$('#modifRech').attr('href').substr(16) + '?';
            }                                                          //
            var result = Meteor.http.call('GET', linkListOffers, initParamsSort(page));
                                                                       //
            if (result.statusCode < 200 || result.statusCode >= 300) {
                Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'statusCode = ' + result.statusCode + ' | URL = ' + link + ' | Options = ' + JSON.stringify(initParamsSort(page)));
                return;                                                // 31
            }                                                          //
        } catch (e) {                                                  //
            Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + link + ' | Options = ' + JSON.stringify(initParamsSort(page)));
            return;                                                    // 35
        }                                                              //
                                                                       //
        var $ = cheerio.load(iconv.decode(result.content, 'iso-8859-1'));
                                                                       //
        $(selectors.offerItem).each(function (index, el) {             // 40
                                                                       //
            var offerLink = $(this).find(selectors.offerLink).attr('href');
                                                                       //
            var tabOfferLink = offerLink.split('offre');               // 44
            offerLink = tabOfferLink[0] + 'offre?offre' + tabOfferLink[2];
            offerLink = website.url + offerLink.substr(1);             // 46
                                                                       //
            offersNb++;                                                // 48
            try {                                                      // 49
                var opt = initParams();                                // 50
                opt.encoding = null;                                   // 51
                opt.responseType = 'buffer';                           // 52
                var pageOffer = Meteor.http.call('GET', offerLink, opt);
                                                                       //
                if (pageOffer.statusCode >= 200 && pageOffer.statusCode < 300) {
                    var $$ = cheerio.load(iconv.decode(pageOffer.content, 'iso-8859-1'));
                                                                       //
                    offerDate = moment($(this).find(selectors.date).text().trim(), 'ddd MMM DD HH:mm:ss z YYYY').toDate();
                                                                       //
                    // Stop 'each()' if offer is too old               //
                    if (search.datePub != null) {                      // 61
                        if (offerDate < search.datePub) {              // 62
                            isLastPage = true;                         // 63
                            return false;                              // 64
                        }                                              //
                    }                                                  //
                                                                       //
                    var offer = new Object();                          // 68
                    offer.search = search;                             // 69
                    offer.websites = [{                                // 70
                        website: website._id,                          // 71
                        url: offerLink                                 // 72
                    }];                                                //
                    offer.dateScrap = new Date();                      // 74
                    offer.datePub = offerDate;                         // 75
                    offer.position = $(this).find(selectors.position).text();
                    offer.location = $(this).find(selectors.location).text().trim();
                    offer.company = $(this).find(selectors.company).text().trim();
                    offer.contractDisplayed = $(this).find(selectors.contract).text();
                    offer.contractEquivalence = $(this).find(selectors.contract).text();
                                                                       //
                    offer.description = {                              // 83
                        small: $(this).find(selectors.descrSmall).text(),
                        large: ''                                      // 85
                    };                                                 //
                                                                       //
                    var descrLarge = '';                               // 88
                    $$(selectors.descrLarge).each(function (index, el) {
                        descrLarge += $(this).html().trim();           // 90
                    });                                                //
                    offer.description.large = descrLarge;              // 92
                                                                       //
                    insertOffersRaw(offer);                            // 94
                    offersNbSucces++;                                  // 95
                } else {                                               //
                    Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'StatusCode:' + pageOffer.statusCode + ' | URL = ' + url);
                }                                                      //
            } catch (e) {                                              //
                Meteor.call('insertLog', ['public.error.scrapGeneral', website.name], 'Exception = ' + JSON.stringify(e) + ' | URL = ' + url);
            }                                                          //
        });                                                            //
                                                                       //
        // Condition to know if the current page is the last page (<.......> : depends on your website)
        if (!$('nav.pagination > a#js-pagination-next.suivant').length) {
            isLastPage = true;                                         // 106
        } else {                                                       //
            page++;                                                    // 108
        }                                                              //
    } while (!isLastPage);                                             //
    if (offersNb !== offersNbSucces) {                                 // 111
        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapNbOffers', offersNb - offersNbSucces, offersNb, website.name], 'offersNb:' + offersNb + ' - offersNbSucces:' + offersNbSucces);
    }                                                                  //
};                                                                     //
                                                                       //
initParamsCadremploi = function (search, options) {                    // 117
    var options = initParams();                                        // 118
    var params = new Object();                                         // 119
    var idRegions = { 'Alsace': 1, 'Aquitaine': 2, 'Auvergne': 3, 'Basse-Normandie': 4, 'Bourgogne': 5, 'Bretagne': 6, 'Centre': 7, 'Champagne-Ardenne': 8, 'Corse': 9, 'Franche-Comté': 10, 'Guadeloupe': 22, 'Guyane': 22, 'Haute-Normandie': 11, 'Île-de-France': 12, 'La-Réunion': 22, 'Languedoc-Roussillon': 13, 'Limousin': 14, 'Lorraine': 15, 'Martinique': 22, 'Mayotte': 22, 'Midi-Pyrénées': 16, 'Nord-Pas-de-Calais': 17, 'Pays-de-la-Loire': 18, 'Picardie': 19, 'Poitou-Charentes': 20, 'Provence-Alpes-Côte-d\'Azur': 21, 'Rhône-Alpes': 22 };
    var idContracts = { 'CDI': [1, 5], 'CDD': [2], 'Stage': [2], 'Apprentissage': [2], 'Freelance': [7, 9] };
    var paramContracts = new Array();                                  // 122
                                                                       //
    // General                                                         //
    params.mth = 'Rechercher';                                         // 125
    params.redirect = '/emploi/recherche_offres';                      // 126
    params.motscles = search.keyword;                                  // 127
                                                                       //
    // Location                                                        //
    if (search.locationId != null) {                                   // 130
        if (search.location.typeArea === 'region') {                   // 131
            params.chk_reg = idRegions[search.location.region];        // 132
        } else {                                                       //
            params.chk_dep = search.location.coDepartment;             // 134
        }                                                              //
    }                                                                  //
                                                                       //
    // Contracts                                                       //
    if (search.contracts == null) {                                    // 139
        params.chk_tyc = '1,2,5,7,9';                                  // 140
    } else {                                                           //
        arrayContracts = new Array();                                  // 142
        _.map(search.contracts, function (c) {                         // 143
            arrayContracts = _.union(arrayContracts, idContracts[c]);  // 144
        });                                                            //
        params.chk_tyc = arrayContracts.join();                        // 146
                                                                       //
        delete arrayContracts;                                         // 148
    }                                                                  //
                                                                       //
    options.params = params;                                           // 151
                                                                       //
    return options;                                                    // 153
};                                                                     //
                                                                       //
initParamsSort = function (page) {                                     // 156
    var options = initParams();                                        // 157
    options.encoding = null;                                           // 158
    options.responseType = 'buffer';                                   // 159
                                                                       //
    var params = new Object();                                         // 161
                                                                       //
    params.tri = 'publishedDate';                                      // 163
    params.page = page;                                                // 164
                                                                       //
    options.params = params;                                           // 166
                                                                       //
    return options;                                                    // 168
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=cadremploi.js.map
