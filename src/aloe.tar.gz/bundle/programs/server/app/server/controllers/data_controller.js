(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/controllers/data_controller.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * make a array with id of web site                                    //
 * @param  {Object}   Web sites from offersRaw                         //
 * @return {Array}    array sorted and uniq id                         //
 */                                                                    //
var createWebsiteId = function (websites) {                            // 6
	var ids = [];                                                         // 7
	_.each(websites, function (row) {                                     // 8
		ids.push(row.website);                                               // 9
	});                                                                   //
	return _.uniq(ids);                                                   // 11
};                                                                     //
                                                                       //
/**                                                                    //
* check if an offer is already inserted in the database Offers         //
* @param  {Object} rawOffer 		The offer to check                       //
* @return {Object}          		this object contain the result of the analyse
*         similar.value	 			true if similar, else false                //
*         similar.cacheOfferId		_id of the offer on Offers database    //
*         similar.toCheckOfferId	undefined                             //
*         similarities.company		true if company 	is the same between One offer in Offers database and rawOffer, else false
*         similarities.position		true if position 	is the same between One offer in Offers database and rawOffer, else false
*         similarities.location		true if location 	is the same between One offer in Offers database and rawOffer, else false
*         similarities.website		true if website 	is the same between One offer in Offers database and rawOffer, else false
*         similarities.url			true if url 		is the same between One offer in Offers database and rawOffer, else false
*         similarities.description	true if description is the same between One offer in Offers database and rawOffer, else false
*         reCheck					true if the algorithm is not sure about the similarity
*/                                                                     //
var checkSimpleSimilarities = function (rawOffer) {                    // 29
	//initialization of the returned object                               //
	var checkResult = {                                                   // 31
		similar: {                                                           // 32
			value: false,                                                       // 33
			cacheOfferId: undefined,                                            // 34
			toCheckOfferId: undefined                                           // 35
		},                                                                   //
		similarities: {                                                      // 37
			company: undefined,                                                 // 38
			position: undefined,                                                // 39
			location: undefined,                                                // 40
			website: undefined,                                                 // 41
			url: undefined,                                                     // 42
			description: undefined                                              // 43
		},                                                                   //
		reCheck: false                                                       // 45
	};                                                                    //
                                                                       //
	//we check if the offer is stored in our server cache by matching the url
	var offer = Offers.findOne({                                          // 49
		websites: {                                                          // 50
			$elemMatch: {                                                       // 51
				url: rawOffer.websites[0].url                                      // 52
			}                                                                   //
		}                                                                    //
	});                                                                   //
                                                                       //
	if (offer) {                                                          // 57
		//the offer is already in the cache                                  //
		checkResult.similarities.company = true;                             // 59
		checkResult.similarities.position = true;                            // 60
		checkResult.similarities.location = true;                            // 61
		checkResult.similarities.website = true;                             // 62
		checkResult.similarities.url = true;                                 // 63
		checkResult.similarities.description = true;                         // 64
		checkResult.similar.value = true;                                    // 65
		checkResult.similar.cacheOfferId = offer._id;                        // 66
	} else {                                                              //
		offer = null;                                                        // 68
		checkResult.similarities.url = false;                                // 69
                                                                       //
		//for each offer in the server cache                                 //
		_.each(Offers.find().fetch(), function (offer) {                     // 72
			if (!checkResult.similar.value && !checkResult.reCheck) {           // 73
                                                                       //
				//we check if the offer is from the same company                   //
				if (offer.company.toUpperCase() === rawOffer.company.toUpperCase()) {
					checkResult.similarities.company = true;                          // 77
                                                                       //
					//we check if the offers titles are nearly similar                //
					if (formateText(offer.position) === formateText(rawOffer.position)) {
						checkResult.similarities.position = true;                        // 81
                                                                       //
						if (isLocIncluded(offer.effectiveLocationId, rawOffer.effectiveLocationId) !== -1) {
							checkResult.similarities.location = true;                       // 84
                                                                       //
							if (isSameWebsite(offer, rawOffer)) {                           // 86
                                                                       //
								checkResult.similarities.website = true;                       // 88
								if (offer.description.large === rawOffer.description.large) {  // 89
									//DUPLICATION                                                 //
									checkResult.similarities.description = true;                  // 91
									checkResult.similar.value = true;                             // 92
									checkResult.similar.cacheOfferId = offer._id;                 // 93
								}                                                              //
							} else {                                                        //
								//MAYBE DUPLICATION                                            //
								checkResult.similarities.website = false;                      // 97
								checkResult.reCheck = true;                                    // 98
								checkResult.similar.value = true;                              // 99
								checkResult.similar.cacheOfferId = offer._id;                  // 100
							}                                                               //
						} else {                                                         //
							checkResult.similarities.location = false;                      // 103
						}                                                                //
					} else {                                                          //
						checkResult.similarities.position = false;                       // 106
					}                                                                 //
				} else {                                                           //
					checkResult.similarities.company = false;                         // 109
				}                                                                  //
			}                                                                   //
		});                                                                  //
	}                                                                     //
	return checkResult;                                                   // 114
};                                                                     //
                                                                       //
/**                                                                    //
 * check if 2 strings are similar                                      //
 * @param  {String} text1 Text to compare (plain)                      //
 * @param  {String} text2 Text to compare (plain)                      //
 * @return {Boolean}      True is texts are similar, False if not      //
 */                                                                    //
var checkComplexeSimilarities = function (text1, text2) {              // 123
	//sie difference between the two texts                                //
	var sizeDifference = Math.abs(text1.length - text2.length);           // 125
	//if the size of a smallest text is over 45% the size of the larger text
	if (100 * (Math.min(text1.length, text2.length) / Math.max(text1.length, text2.length)) >= 45) {
		//Jaccard coeficient                                                 //
		var coefSimilarity = jaccard.index(text1.split(' '), text2.split(' ')) * 100;
		return !(coefSimilarity < Meteor.settings.minJaccardSimilarityThreshold);
	} else {                                                              //
		//-compare- the Levenshtein distance (minimum number of editions beetween Two texts)
		//-with-	the difference between the two texts                        //
		//Reveals the propention that the smallest text is included into the larger one
		var coefSimilarity = Math.min(levenshtein.get(text1, text2), sizeDifference) / Math.max(levenshtein.get(text1, text2), sizeDifference) * 100;
		return !(coefSimilarity < Meteor.settings.minLevenshteinSimilarityThreshold);
	}                                                                     //
};                                                                     //
                                                                       //
/**                                                                    //
 * Define what to do to each new raw offers inserted in the RawOffers database
 * @param {Object} rawOffer The raw offer inserted                     //
 */                                                                    //
var offersRawObserveAddedAction = function (rawOffer) {                // 144
	//calculation of the effective location ID from the scrapped location
	var effectiveLocationId = getEffectiveLocation(rawOffer.location);    // 146
	if (!effectiveLocationId) {                                           // 147
		//if we are not able to find the location ID, we use the locationId from search Object
		insertLocationCache(rawOffer.location, rawOffer.search.locationId);  // 149
		effectiveLocationId = rawOffer.search.locationId;                    // 150
	}                                                                     //
	var data = {                                                          // 152
		keywords: replaceSpec(rawOffer.search.keyword).split(" "),           // 153
		websitesId: createWebsiteId(rawOffer.websites),                      // 154
		websites: rawOffer.websites,                                         // 155
		location: rawOffer.location,                                         // 156
		effectiveLocationId: effectiveLocationId,                            // 157
		originalsLocations: new Array(rawOffer.search.locationId),           // 158
		datePub: rawOffer.datePub,                                           // 159
		description: rawOffer.description,                                   // 160
		dateScrap: rawOffer.dateScrap,                                       // 161
		company: rawOffer.company,                                           // 162
		salary: rawOffer.salary,                                             // 163
		position: rawOffer.position,                                         // 164
		contractDisplayed: rawOffer.contractDisplayed,                       // 165
		contractEquivalence: rawOffer.contractEquivalence                    // 166
	};                                                                    //
                                                                       //
	//get the checkResult Object                                          //
	rawOffer.effectiveLocationId = effectiveLocationId;                   // 170
	var checkResult = checkSimpleSimilarities(rawOffer);                  // 171
                                                                       //
	//If not similarity: insertion                                        //
	//else update the already inserted data                               //
	if (!checkResult.similar.value) {                                     // 175
		data.effectiveLocation = getLocationScale(data.effectiveLocationId);
                                                                       //
		Offers.insert(data);                                                 // 178
	} else {                                                              //
		if (checkResult.reCheck) {                                           // 180
			var isSimilar = checkComplexeSimilarities(formateText(htmlToTextWithoutHeaders(Offers.findOne({ _id: checkResult.similar.cacheOfferId }).description.large)), formateText(htmlToTextWithoutHeaders(rawOffer.description.large)));
			if (isSimilar) {                                                    // 185
				updateOffer(checkResult.similar.cacheOfferId, data);               // 186
			}                                                                   //
		} else {                                                             //
			updateOffer(checkResult.similar.cacheOfferId, data);                // 189
		}                                                                    //
	}                                                                     //
	//Erase the raw offer from the RawOFfers database                     //
	OffersRaw.remove({ "_id": rawOffer._id });                            // 193
};                                                                     //
                                                                       //
/**                                                                    //
 * Update an offers with the data in the updateData Object             //
 * @param  {String} originOfferId Id of the offer that have to be updateData
 * @param  {Object} updateData    contains the data of the updated offer:
 *                  keywords            : keywords array,              //
					websites            : origin website Object,                      //
					location            : scraped value of the location,              //
					effectiveLocationId : effectiveLocationId,                        //
					datePub             : publication Date,                           //
					description         : description Object,                         //
					dateScrap           : last scrap date,                            //
					company             : company name,                               //
					salary              : scraped salary,                             //
					position            : scraped position,                           //
					contractDisplayed   : scraped contract,                           //
					contractEquivalence : equivalence contract                        //
 * @return {Object} Mongo Object Command Output                        //
 */                                                                    //
var updateOffer = function (originOfferId, updateData) {               // 214
	originOffer = Offers.findOne({ _id: originOfferId });                 // 215
                                                                       //
	//set the larger descrition as the offer descrition in the server cache
	if (updateData.description.large.length > originOffer.description.large.length) {
		var description = updateData.description;                            // 220
	} else {                                                              //
		var description = originOffer.description;                           // 222
	}                                                                     //
                                                                       //
	//check if locations are compatibles, and get the more precise of the two locations
	var effectiveLocationId = isLocIncluded(originOffer.effectiveLocationId, updateData.effectiveLocationId);
	if (effectiveLocationId === -1) {                                     // 227
		//if locations are not compatible, take the location from the origin offer in priority
		//if the origin offer effectivelocationId is undefined, take the one from updateData
		effectiveLocationId = originOffer.effectiveLocationId || updateData.effectiveLocationId;
	}                                                                     //
                                                                       //
	//select the more precise location                                    //
	//effectiveLocationId is the more precise locationId                  //
	//if the originOffer.effectiveLocationId equals effectiveLocationId   //
	//it means that le more precise location if the one from the originOffer
	if (effectiveLocationId === originOffer.effectiveLocationId) {        // 237
		var location = originOffer.location;                                 // 238
		var effectiveLocation = originOffer.effectiveLocation;               // 239
	} else {                                                              //
		var location = updateData.location;                                  // 241
		var effectiveLocation = getLocationScale(updateData.effectiveLocationId);
	}                                                                     //
                                                                       //
	//select the most recent publication date                             //
	var originOfferDate = new Date(originOffer.datePub).getTime();        // 246
	var updateDataDate = new Date(updateData.datePub).getTime();          // 247
	var datePub = new Date(Math.max(originOfferDate, updateDataDate));    // 248
                                                                       //
	//insert the website from the updateData if not already in the website Array
	if (isSameWebsite(originOffer, updateData)) {                         // 251
		var websites = originOffer.websites;                                 // 252
	} else {                                                              //
		var websites = _.union(originOffer.websites, updateData.websites);   // 254
	}                                                                     //
                                                                       //
	//initialization of the updateObject                                  //
	var updateObject = {                                                  // 258
		keywords: _.union(originOffer.keywords, updateData.keywords),        // 259
		websitesId: createWebsiteId(websites),                               // 260
		websites: websites,                                                  // 261
		location: location,                                                  // 262
		effectiveLocationId: effectiveLocationId,                            // 263
		effectiveLocation: effectiveLocation,                                // 264
		originalsLocations: _.union(originOffer.originalsLocations, updateData.originalsLocations),
		datePub: datePub,                                                    // 266
		description: description,                                            // 267
		dateScrap: updateData.dateScrap,                                     // 268
		position: updateData.position || originOffer.position,               // 269
		company: updateData.company || originOffer.company,                  // 270
		salary: updateData.salary || originOffer.salary,                     // 271
		contractDisplayed: updateData.contractDisplayed || originOffer.contractDisplayed,
		contractEquivalence: updateData.contractEquivalence || originOffer.contractEquivalence
	};                                                                    //
                                                                       //
	//update query                                                        //
	return Offers.update({ _id: originOfferId }, updateObject);           // 277
};                                                                     //
                                                                       //
/**                                                                    //
 * At meteor startup, initialize the offersRaw observer:               //
 * On "added" action it run the function offersRawObserveAddedAction   //
 */                                                                    //
Meteor.startup(function () {                                           // 284
	OffersRaw.find().observe({                                            // 285
		added: function (rawOffer) {                                         // 286
			offersRawObserveAddedAction(rawOffer);                              // 287
		}                                                                    //
	});                                                                   //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=data_controller.js.map
