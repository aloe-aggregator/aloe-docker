(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/controllers/aloe_controller.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
    // Set default language of i18n                                    //
    i18n.setDefaultLanguage(Meteor.settings['public'].languages.serverLanguage);
    i18n.setLanguage(Meteor.settings['public'].languages.serverLanguage);
                                                                       //
    // Set default display to i18n                                     //
    i18n.showMissing('<%= label %>');                                  // 7
                                                                       //
    // Set default number in array Google API Key                      //
    idGglApiKey = 0;                                                   // 10
    // Set the number of Google API Key                                //
    nbGglKeyAPI = Meteor.settings['public'].gglKeyAPI.length;          // 12
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 15
    /**                                                                //
     * search offers in websites with parameters                       //
     * only launch each search modules asynchronously                  //
      * Only keyword, websites and userId are necessary                //
     * @param  {String}       keyword     Keyword to search            //
     * @param  {List[String]} websites    Websites to search           //
     * @param  String         userId      Session Id of the user       //
      * Others can be defined or not (null if not defined)             //
     * @param  {String}       locationId  API Google ID                //
     * @param  {Date}         datePub     Date max to search           //
     * @param  {List[String]} contracts   List contracts defined in mongo
     */                                                                //
    search: function (keyword, locationId, datePub, contracts, websites, userId) {
        NonEmptyString = Match.Where(function (str) {                  // 31
            check(str, String);                                        // 32
            return str.length > 0;                                     // 33
        });                                                            //
        check(keyword, NonEmptyString);                                // 35
        keyword = keyword.trim();                                      // 36
                                                                       //
        check(websites, [String]);                                     // 38
        WebsitesInArray = Match.Where(function (websites) {            // 39
            _.map(websites, function (ws) {                            // 40
                if (Websites.find({                                    // 41
                    name: ws                                           // 42
                }).count === 0) {                                      //
                    return false;                                      // 44
                }                                                      //
            });                                                        //
            return true;                                               // 47
        });                                                            //
        check(websites, WebsitesInArray);                              // 49
                                                                       //
        if (locationId != null) {                                      // 51
            check(locationId, NonEmptyString);                         // 52
        }                                                              //
                                                                       //
        if (contracts != null) {                                       // 55
            check(contracts, [String]);                                // 56
            ContractsInArray = Match.Where(function (contracts) {      // 57
                _.map(contracts, function (ct) {                       // 58
                    if (Contracts.find({                               // 59
                        name: ct                                       // 60
                    }).count === 0) {                                  //
                        return false;                                  // 62
                    }                                                  //
                });                                                    //
                return true;                                           // 65
            });                                                        //
            check(contracts, ContractsInArray);                        // 67
        }                                                              //
                                                                       //
        if (datePub != null) {                                         // 70
            check(datePub, Date);                                      // 71
        }                                                              //
                                                                       //
        // location object initialization                              //
        location = getLocationWithIdFromAPI(locationId, userId);       // 75
        if (location === -1) {                                         // 76
            return;                                                    // 77
        }                                                              //
                                                                       //
        // search object initialization                                //
        search = new Object();                                         // 81
        search.keyword = keyword;                                      // 82
        search.locationId = locationId;                                // 83
        search.location = location;                                    // 84
        search.datePub = datePub;                                      // 85
        search.contracts = contracts;                                  // 86
                                                                       //
        // Add autocomplete keywords                                   //
        Meteor.call('addAutocompleteKeyword', keyword);                // 89
                                                                       //
        _.map(websites, function (ws) {                                // 91
            Meteor.setTimeout(function () {                            // 92
                var fn = global['search' + ws];                        // 93
                if (typeof fn === 'function') {                        // 94
                    try {                                              // 95
                        fn(search, userId);                            // 96
                    } catch (e) {                                      //
                        Meteor.call('throwErrorWithLog', userId, ['public.error.scrapGeneral', ws], 'Exception = ' + JSON.stringify(e));
                    }                                                  //
                }                                                      //
            }, 0);                                                     //
        });                                                            //
    },                                                                 //
                                                                       //
    /**                                                                //
     * generate a unique id string for user session                    //
     * @return {String} Unique string for the user session             //
     */                                                                //
    generateGUID: function () {                                        // 109
        function s4() {                                                // 110
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }                                                              //
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    },                                                                 //
                                                                       //
    /**                                                                //
     * throw an error to the user                                      //
     * insert error in the mongo database                              //
     * @param  {String}       userId         id string of user session
     * @param  {List[String]} messageParams  params for the internalionalization ['messageId', [params,...]]
     */                                                                //
    throwError: function (userId, messageParams) {                     // 122
        Errors.insert({                                                // 123
            userId: userId,                                            // 124
            messageParams: messageParams                               // 125
        });                                                            //
    },                                                                 //
                                                                       //
    /**                                                                //
     * insert a log in the mongo database                              //
     * @param  {String|List[String]} message        string or params for the internalionalization ['messageId', [params,...]]
     * @param  {String|List[String]} messageParams  string or params for the internalionalization ['messageId', [params,...]]
     */                                                                //
    insertLog: function (message, explanation) {                       // 134
        if (Array.isArray(message)) {                                  // 135
            message = i18n.apply(this, message);                       // 136
        }                                                              //
        if (Array.isArray(explanation)) {                              // 138
            explanation = i18n.apply(this, explanation);               // 139
        }                                                              //
        Logs.insert({                                                  // 141
            date: new Date(),                                          // 142
            message: message,                                          // 143
            explanation: explanation                                   // 144
        });                                                            //
    },                                                                 //
                                                                       //
    /**                                                                //
     * insert a log in the mongo database                              //
     * and throw an error to the client                                //
     * @param  {String}              userId         id string of user session
     * @param  {String|List[String]} message        string or params for the internalionalization ['messageId', [params,...]]
     * @param  {String|List[String]} messageParams  string or params for the internalionalization ['messageId', [params,...]]
     */                                                                //
    throwErrorWithLog: function (userId, messageParams, explanation) {
        Meteor.call('insertLog', i18n.apply(this, messageParams), explanation);
        Meteor.call('throwError', userId, messageParams);              // 157
    },                                                                 //
                                                                       //
    /**                                                                //
     * send a mail                                                     //
     * @param  {String} from     string                                //
     * @param  {String} subject  string                                //
     * @param  {String} text     string                                //
     */                                                                //
    sendEmail: function (from, subject, text) {                        // 166
        check([from, subject, text], [String]);                        // 167
                                                                       //
        // Let other method calls from the same client start running,  //
        // without waiting for the email sending to complete.          //
        this.unblock();                                                // 171
                                                                       //
        Email.send({                                                   // 173
            to: Meteor.settings.contactEMail,                          // 174
            from: from,                                                // 175
            subject: subject,                                          // 176
            text: text                                                 // 177
        });                                                            //
    },                                                                 //
                                                                       //
    /**                                                                //
     * delete an error by id                                           //
     * @param {String} id idError                                      //
     */                                                                //
    deleteError: function (id) {                                       // 185
        Errors.remove(id);                                             // 186
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=aloe_controller.js.map
