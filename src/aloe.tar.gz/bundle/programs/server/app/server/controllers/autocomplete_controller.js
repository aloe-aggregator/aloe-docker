(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/controllers/autocomplete_controller.js                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    /**                                                                //
     * return an autocomplete list of the keyword input                //
     * limited by 5 results and if the keyword is in the               //
     * 75% more used keyword                                           //
     * @param  {String} string to autocomplete                         //
     * @return {List[String]|null}                                     //
     */                                                                //
    autocompleteKeywordInput: function (keyword) {                     // 9
        listAutocomplete = new Array();                                // 10
        KeywordAutocomplete.find({                                     // 11
            keyword: new RegExp("^" + keyword.toLowerCase()),          // 12
            displayable: 1                                             // 13
        }, {                                                           //
            sort: {                                                    // 15
                relevance: -1                                          // 16
            },                                                         //
            limit: 5                                                   // 18
        }).forEach(function (keywordObject) {                          //
            listAutocomplete.push(keywordObject.keyword);              // 20
        });                                                            //
        return listAutocomplete;                                       // 22
    },                                                                 //
                                                                       //
    /**                                                                //
     * add to the keywordAutocomplete collection each word of          //
     * the user search who is an alphanumeric word                     //
     * if the keyword is already present, the relevance is             //
     * incremented by 1                                                //
     * Update the displayable input if the keyword is in the 75% more common word
     * @param {String} the keyword search                              //
     */                                                                //
    addAutocompleteKeyword: function (keywords) {                      // 33
        var words = replaceSpec(keywords).split(" ");                  // 34
        var alphanumeric = new RegExp("^[a-zA-Z0-9]*$");               // 35
        var numeric = new RegExp("^[0-9]*$");                          // 36
        var calculationDisplayable = false;                            // 37
                                                                       //
        // Add word to the collection                                  //
        _.map(words, function (word) {                                 // 40
            if (word.length >= 3) {                                    // 41
                if (alphanumeric.test(word) && !numeric.test(word)) {  // 42
                    calculationDisplayable = true;                     // 43
                    var exist = KeywordAutocomplete.find({             // 44
                        keyword: word                                  // 45
                    }).count();                                        //
                    if (exist === 0) {                                 // 47
                        var keywordObject = new Object();              // 48
                        keywordObject.keyword = word.toLowerCase();    // 49
                        keywordObject.relevance = 1;                   // 50
                        keywordObject.displayable = 0;                 // 51
                        KeywordAutocomplete.insert(keywordObject);     // 52
                    } else {                                           //
                        KeywordAutocomplete.update({                   // 54
                            keyword: word                              // 55
                        }, {                                           //
                            $inc: {                                    // 57
                                relevance: +1                          // 58
                            }                                          //
                        });                                            //
                    }                                                  //
                }                                                      //
            }                                                          //
        });                                                            //
        // Calculation if the input is displayable                     //
        if (calculationDisplayable) {                                  // 66
            var keywordsSize = KeywordAutocomplete.find().count();     // 67
            var thirdQuartile = Math.ceil(3 * keywordsSize / 4);       // 68
            var keywordsList = KeywordAutocomplete.find({}, {          // 69
                sort: {                                                // 70
                    relevance: -1                                      // 71
                }                                                      //
            }).fetch();                                                //
            var thirdQuartileRelevance = keywordsList[thirdQuartile - 1].relevance;
            KeywordAutocomplete.update({                               // 75
                relevance: {                                           // 76
                    $gt: thirdQuartileRelevance                        // 77
                }                                                      //
            }, {                                                       //
                $set: {                                                // 80
                    displayable: 1                                     // 81
                }                                                      //
            }, {                                                       //
                multi: true                                            // 84
            });                                                        //
            KeywordAutocomplete.update({                               // 86
                relevance: {                                           // 87
                    $lte: thirdQuartileRelevance                       // 88
                }                                                      //
            }, {                                                       //
                $set: {                                                // 91
                    displayable: 0                                     // 92
                }                                                      //
            }, {                                                       //
                multi: true                                            // 95
            });                                                        //
        }                                                              //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=autocomplete_controller.js.map
