(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/controllers/db_controller.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
* Return the number of days for retention delay based on statistics    //
* @param  {String} _id of WebSite collection                           //
* @return {Integer} Number of days                                     //
*/                                                                     //
getThreshold = function (websiteId) {                                  // 6
	var dayMax = Meteor.settings['cacheOffersRetentionDelay'].daysMax;    // 7
	var dayMin = Meteor.settings['cacheOffersRetentionDelay'].daysMin;    // 8
	var dateNow = moment(new Date()).format('YYYYMM');                    // 9
	var statsOfMonth = Stats.findOne({ dateString: dateNow });            // 10
	var website = Websites.findOne({ _id: websiteId });                   // 11
                                                                       //
	var keysSorted = Object.keys(statsOfMonth.presence).sort(function (a, b) {
		return statsOfMonth.presence[a] - statsOfMonth.presence[b];          // 13
	});                                                                   //
                                                                       //
	var presenceMin = statsOfMonth.presence[keysSorted[0]];               // 15
	var presenceMax = statsOfMonth.presence[keysSorted[_.size(keysSorted) - 1]];
                                                                       //
	var a = (dayMin - dayMax) / (presenceMax - presenceMin);              // 18
	var b = dayMin - a * presenceMax;                                     // 19
                                                                       //
	return Math.round(a * statsOfMonth.presence[website.name] + b);       // 21
};                                                                     //
                                                                       //
/**                                                                    //
* Get contract label for Aloe                                          //
* @param  {String} Contract name on the website                        //
* @param  {String} Name of the website                                 //
* @return {String} name of contract in aloe                            //
*/                                                                     //
contractScrapToAloe = function (contractSite, websiteName) {           // 30
                                                                       //
	//Check if contractSite is not empty                                  //
	if (contractSite === "" || contractSite === null) {                   // 33
		return null;                                                         // 34
	}                                                                     //
                                                                       //
	//Make the search object                                              //
	var fullName = "websites." + websiteName;                             // 38
	var search = new Object();                                            // 39
	search[fullName] = { $in: [contractSite] };                           // 40
                                                                       //
	//First search with the complet contractSite                          //
	var contractNames = Contracts.findOne(search);                        // 43
	if (contractNames != null) {                                          // 44
		return contractNames.name;                                           // 45
	}                                                                     //
                                                                       //
	//Second search on all website with the full contractSite             //
	delete search[fullName];                                              // 49
	var contractNames = [];                                               // 50
	var res;                                                              // 51
	Websites.find({}).forEach(function (site) {                           // 52
		if (site.name !== websiteName) {                                     // 53
			search = new Object();                                              // 54
			fullName = "websites." + site.name;                                 // 55
			search[fullName] = { $in: [contractSite] };                         // 56
			res = Contracts.findOne(search);                                    // 57
			if (res != null) {                                                  // 58
				contractNames.push(res);                                           // 59
			}                                                                   //
		}                                                                    //
	});                                                                   //
                                                                       //
	contractNames = _.uniq(contractNames);                                // 64
	if (contractNames.length == 1 && contractNames[0] != null) {          // 65
		return contractNames[0];                                             // 66
	}                                                                     //
                                                                       //
	//split of contractSite in array                                      //
	var tmp = contractSite.split(/(?:,|;| |\||\/|_|\+)+/);                // 70
	var arrayContracts = [];                                              // 71
	_.each(tmp, function (word) {                                         // 72
		if (_.indexOf(arrayContracts, word) === -1) arrayContracts.push(word);
	});                                                                   //
                                                                       //
	fullName = "websites." + websiteName;                                 // 76
	search = new Object();                                                // 77
	search[fullName] = { $in: arrayContracts };                           // 78
                                                                       //
	//Third search (only on websiteName), if a answer is find, return the name.
	var contractNames = Contracts.findOne(search);                        // 81
	if (contractNames != null) {                                          // 82
		return contractNames.name;                                           // 83
	}                                                                     //
                                                                       //
	//Fourth search (on all web sites)                                    //
	delete search[fullName];                                              // 87
	contractNames = [];                                                   // 88
	res = "";                                                             // 89
	Websites.find({}).forEach(function (site) {                           // 90
		if (site.name !== websiteName) {                                     // 91
			search = new Object();                                              // 92
			fullName = "websites." + site.name;                                 // 93
			search[fullName] = { $in: arrayContracts };                         // 94
			res = Contracts.findOne(search);                                    // 95
			if (res != null) {                                                  // 96
				contractNames.push(res);                                           // 97
			}                                                                   //
		}                                                                    //
	});                                                                   //
                                                                       //
	contractNames = _.uniq(contractNames);                                // 102
	if (contractNames.length == 1 && contractNames[0] != null) {          // 103
		return contractNames[0];                                             // 104
	}                                                                     //
                                                                       //
	//Else: no match                                                      //
	Meteor.call('insertLog', ['server.error.contractNotFound'], "contract = [" + contractSite + "] | website = [" + websiteName + "]");
	return null;                                                          // 109
};                                                                     //
                                                                       //
/**                                                                    //
* Clear old location in LocationsScrap collection                      //
*/                                                                     //
clearLocationScrap = function () {                                     // 115
	var dayDiff = 0;                                                      // 116
	var isDeprecated = false;                                             // 117
	LocationsScrap.find({}).forEach(function (location) {                 // 118
		dayDiff = getDayGap(location.insertDay, new Date(), 'd');            // 119
		isDeprecated = dayDiff > Meteor.settings.cacheLocationsRetentionDelay;
		if (isDeprecated) {                                                  // 121
			LocationsScrap.remove(location._id);                                // 122
		}                                                                    //
	});                                                                   //
};                                                                     //
                                                                       //
/**                                                                    //
* Clear old location in LocationsScale collection                      //
*/                                                                     //
clearLocationScale = function () {                                     // 130
	var dayDiff = 0;                                                      // 131
	var isDeprecated = false;                                             // 132
	LocationsLadder.find({}).forEach(function (location) {                // 133
		dayDiff = getDayGap(location.insertDay, new Date(), 'd');            // 134
		isDeprecated = dayDiff > Meteor.settings.cacheLocationsRetentionDelay;
		if (isDeprecated) {                                                  // 136
			LocationsLadder.remove(location._id);                               // 137
		}                                                                    //
	});                                                                   //
};                                                                     //
                                                                       //
/**                                                                    //
* Format the object with web site to search offer                      //
* @param  {Object} A mongo search of Websites                          //
* @return {Object} The object to search.                               //
*/                                                                     //
formatWebSites = function (websites) {                                 // 147
	webSiteRename = [];                                                   // 148
	_.each(websites.fetch(), function (webSite) {                         // 149
		webSiteRename.push(webSite._id);                                     // 150
	});                                                                   //
	return webSiteRename;                                                 // 152
};                                                                     //
                                                                       //
/**                                                                    //
* Remove the old offers and return offers sorted                       //
* @param  {Object} Search criteria                                     //
* @param  {Object} options of criteria                                 //
* @return {Object} Offers cleared and sorted. This is a mongo object. 
*/                                                                     //
getOffers = function (dataSearch, options) {                           // 161
	options.sort = { datePub: -1 };                                       // 162
                                                                       //
	if (dataSearch != null) {                                             // 164
                                                                       //
		var keywords = [];                                                   // 166
		_.map(dataSearch.keywords, function (word) {                         // 167
			keywords.push(replaceSpec(word));                                   // 168
		});                                                                  //
                                                                       //
		//Build of search object                                             //
		var searcher = {                                                     // 172
			"keywords": { $all: keywords }                                      // 173
		};                                                                   //
                                                                       //
		//Format the web sites                                               //
		var websitesRaw;                                                     // 177
		if (dataSearch.websites) websitesRaw = Websites.find({ "_id": { $in: dataSearch.websites } }, { "url": 1 });else websitesRaw = Websites.find({}, { "url": 1 });
		searcher.websitesId = { $in: formatWebSites(websitesRaw) };          // 182
                                                                       //
		if (dataSearch.contracts) searcher.contractEquivalence = { $all: dataSearch.contracts };
                                                                       //
		if (dataSearch.locationId != null) {                                 // 187
			var s1 = cloneObject(searcher);                                     // 188
			var s2 = cloneObject(searcher);                                     // 189
                                                                       //
			var dt = new Date(dataSearch.date);                                 // 191
			locScale = getLocationFromId(dataSearch.locationId);                // 192
			s1['effectiveLocation.' + locScale.typeArea] = locScale[locScale.typeArea];
                                                                       //
			s2.originalsLocations = dataSearch.locationId;                      // 195
                                                                       //
			if (dataSearch.date) {                                              // 197
				s1.datePub = { $gte: dt };                                         // 198
				s2.datePub = { $gte: dt };                                         // 199
			}                                                                   //
                                                                       //
			searcher = {                                                        // 202
				$or: [s1, s2]                                                      // 203
			};                                                                  //
		} else {                                                             //
			if (dataSearch.date) {                                              // 206
				var dt = new Date(dataSearch.date);                                // 207
				searcher.datePub = { $gte: dt };                                   // 208
			}                                                                   //
		}                                                                    //
                                                                       //
		var offersSort = Offers.find(searcher, options);                     // 212
	} else {                                                              //
		//Without search object                                              //
		var offersSort = Offers.find({}, options);                           // 216
	}                                                                     //
                                                                       //
	clearOffersResidualData(offersSort);                                  // 219
                                                                       //
	return offersSort;                                                    // 221
};                                                                     //
                                                                       //
/**                                                                    //
* Remove the old offers.                                               //
* @param {Object} offers with some old                                 //
*/                                                                     //
clearOffersResidualData = function (offersSort) {                      // 228
                                                                       //
	var offersSort = offersSort || Offers.find({});                       // 230
                                                                       //
	//Remove the old offers                                               //
	var dateNow = new Date();                                             // 233
	var offersCleared = offersSort.map(function (offer) {                 // 234
		_.each(offer.websitesId, function (website) {                        // 235
			var timeDiff = Math.abs(dateNow - offer.dateScrap);                 // 236
			var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));            // 237
			if (diffDays >= getThreshold(website)) {                            // 238
				Offers.remove({ _id: offer._id });                                 // 239
			}                                                                   //
		});                                                                  //
	});                                                                   //
};                                                                     //
                                                                       //
/**                                                                    //
* Get the offers from cache and scrapper sorted by date.               //
* @param  {Object} Search criteria                                     //
* @param  {Object} option of criteria                                  //
* @return {Object} Offers cleared and sorted                           //
*/                                                                     //
Meteor.methods({                                                       // 252
	getOffers: function (dataSearch, options) {                           // 253
		if (dataSearch != null) {                                            // 254
			return clear(dataSearch, options);                                  // 255
		}                                                                    //
		return -1;                                                           // 257
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=db_controller.js.map
