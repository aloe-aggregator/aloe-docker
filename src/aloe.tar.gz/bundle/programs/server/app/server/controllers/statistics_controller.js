(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/controllers/statistics_controller.js                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
    OffersRaw.find().observeChanges({                                  // 2
        added: function (id, rawOffer) {                               // 3
            var website = Websites.findOne({ _id: rawOffer.websites[0].website });
            Meteor.call('incrementStats', 'presence', website.name, 1);
        }                                                              //
    });                                                                //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 10
    // type : presence, click ou redirection                           //
    incrementStats: function (type, websiteName, n) {                  // 12
        var now = moment(new Date()).format('YYYYMM');                 // 13
        if (Stats.find({                                               // 14
            dateString: now                                            // 15
        }).count() === 0) {                                            //
            // List of available websites in our Mongo collection      //
            websites = Websites.find();                                // 18
                                                                       //
            var stat = {                                               // 20
                dateString: now,                                       // 21
                presence: new Object(),                                // 22
                click: new Object(),                                   // 23
                redirection: new Object()                              // 24
            };                                                         //
                                                                       //
            websites.forEach(function (ws) {                           // 27
                stat.presence[ws.name] = 0;                            // 28
                stat.click[ws.name] = 0;                               // 29
                stat.redirection[ws.name] = 0;                         // 30
            });                                                        //
                                                                       //
            // Create document for the actual month                    //
            Stats.insert(stat);                                        // 34
        }                                                              //
                                                                       //
        var incModifier = {                                            // 37
            $inc: {}                                                   // 38
        };                                                             //
        incModifier.$inc[type + '.' + websiteName] = n;                // 40
                                                                       //
        Stats.update({                                                 // 42
            dateString: now                                            // 43
        }, incModifier);                                               //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=statistics_controller.js.map
