(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/helpers/helper_string.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
* Replace Special characters                                           //
* @param  {String} text The text to format                             //
* @return {String}      Formated text                                  //
*/                                                                     //
replaceSpec = function (text) {                                        // 6
	var reg = /[àáäâèéêëçìíîïòóôõöøùúûüÿñ_-]/gi;                          // 7
	var TabSpec = {                                                       // 8
		"à": "a", "á": "a", "â": "a", "ã": "a", "ä": "a", "å": "a",          // 9
		"è": "e", "é": "e", "ê": "e", "ë": "e",                              // 10
		"ì": "i", "í": "i", "î": "i", "ï": "i",                              // 11
		"ò": "o", "ó": "o", "ô": "o", "õ": "o", "ö": "o", "ø": "o",          // 12
		"ù": "u", "ú": "u", "û": "u", "ü": "u",                              // 13
		"ÿ": "y",                                                            // 14
		"ç": "c",                                                            // 15
		"ñ": "n",                                                            // 16
		"-": " ", "_": " "                                                   // 17
	};                                                                    //
	return text.replace(reg, function () {                                // 19
		return TabSpec[arguments[0].toLowerCase()];                          // 22
	}).toLowerCase();                                                     //
};                                                                     //
                                                                       //
/**                                                                    //
* Format a text in order to compare with other formated texts          //
* @param  {String} text The text to format                             //
* @return {String}      Formated text                                  //
*/                                                                     //
formateText = function (text) {                                        // 32
	return replaceSpec(text) //Replace special char                       // 33
	.replace(/[^a-z]/gi, ' ') //Keep only alphanumerics                   //
	.replace(/(\b(\w{1,2})\b(\s|$))/g, '') //Remove {1,2} words           //
	.replace(/\s+/g, ' ') //Remove CR                                     //
	//.replace(/\s/g, '')					//Remove spaces                             //
	.toUpperCase().trim(); //Convert to upper case                        //
};                                                                     //
                                                                       //
/**                                                                    //
 * remove all html element in a string                                 //
 * @param  {string} html text                                          //
 * @return {strinf} plain text with no html element                    //
 */                                                                    //
htmlToText = function (html) {                                         // 46
	return cheerio.load('<body>' + html + '</body>')('body').text();      // 47
};                                                                     //
                                                                       //
/**                                                                    //
 * remove unused caracter in a String                                  //
 * @param  {string} str text                                           //
 * @return a string with no unused caracter                            //
 */                                                                    //
removeUnusedCar = function (str) {                                     // 55
	if (Match.test(str, String)) {                                        // 56
		return str.replace(/\s+/g, ' ').trim();                              // 57
	}                                                                     //
	return null;                                                          // 59
};                                                                     //
                                                                       //
/**                                                                    //
 * replace a string with space in the same string with hyphen          //
 * @param  {string} str text                                           //
 * @return a string with hyphen                                        //
 */                                                                    //
spaceToHyphen = function (str) {                                       // 67
	return str.replace(new RegExp(' ', 'g'), '-');                        // 68
};                                                                     //
                                                                       //
/**                                                                    //
 * remove all html element                                             //
 * header                                                              //
 * strong                                                              //
 * and b                                                               //
 * in a string                                                         //
 * @param  {string} html text                                          //
 * @return {strinf} plain text with no html component                  //
 */                                                                    //
htmlToTextWithoutHeaders = function (html) {                           // 80
	var $ = cheerio.load('<body>' + html + '</body>');                    // 81
	$("h1").text('');                                                     // 82
	$("h2").text('');                                                     // 83
	$("h3").text('');                                                     // 84
	$("h4").text('');                                                     // 85
	$("h5").text('');                                                     // 86
	$("strong").text('');                                                 // 87
	$("b").text('');                                                      // 88
	return $('body').text();                                              // 89
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=helper_string.js.map
