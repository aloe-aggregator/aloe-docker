(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/helpers/helper_general.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * clone an object                                                     //
 * @param  {Object} src  object to clone                               //
 * @return the cloned object                                           //
 */                                                                    //
cloneObject = function (src) {                                         // 6
  return JSON.parse(JSON.stringify(src));                              // 7
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=helper_general.js.map
