(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/helpers/helper_date.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * get the gap between 2 dates                                         //
 * @param  {Date}            d1  Date 1                                //
 * @param  {Date}            d2  Date 2 > Date 1                       //
 * @param  {String[s|m|h|d]} u   Unit (s : seconds, m : minutes, h : hours, d : days)
 * @return the gap in number                                           //
 */                                                                    //
getDayGap = function (d1, d2, u) {                                     // 8
    div = 1;                                                           // 9
    switch (u) {                                                       // 10
        case 's':                                                      // 11
            div = 1000;                                                // 12
            break;                                                     // 13
        case 'm':                                                      // 14
            div = 1000 * 60;                                           // 15
            break;                                                     // 16
        case 'h':                                                      // 17
            div = 1000 * 60 * 60;                                      // 18
            break;                                                     // 19
        case 'd':                                                      // 19
            div = 1000 * 60 * 60 * 24;                                 // 21
            break;                                                     // 22
    }                                                                  // 22
                                                                       //
    diff = d2.getTime() - d1.getTime();                                // 25
                                                                       //
    return Math.ceil(diff / div);                                      // 27
};                                                                     //
                                                                       //
/**                                                                    //
 * get a date before an other with a gap in days                       //
 * @param  {Number} nbDays  Number of days to remove                   //
 * @return the date before the gap                                     //
 */                                                                    //
backToPastDay = function (nbDays) {                                    // 35
    return new Date(new Date().getTime() - nbDays * 1000 * 60 * 60 * 24);
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=helper_date.js.map
