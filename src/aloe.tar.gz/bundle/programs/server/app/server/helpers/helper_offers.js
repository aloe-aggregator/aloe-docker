(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/helpers/helper_offers.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
* check if the rawOffer websites.website[0].website attribute          //
* is contained in the offer websites.website array                     //
* @param  {String}  offer                                              //
* @param  {String}  rawOffer                                           //
* @return {Boolean}                                                    //
*/                                                                     //
isSameWebsite = function (offer, rawOffer) {                           // 8
	var same = false;                                                     // 9
	_.each(offer.websites, function (website) {                           // 10
		if (website.website === rawOffer.websites[0].website) same = true;   // 11
	});                                                                   //
	return same;                                                          // 15
};                                                                     //
                                                                       //
/**                                                                    //
* check if the rawOffer websites.website[0].url attribute              //
* is contained in the offer websites.website array                     //
* @param  {String}  offer                                              //
* @param  {String}  rawOffer                                           //
* @return {Boolean}                                                    //
*/                                                                     //
haveSameURL = function (offer, rawOffer) {                             // 25
	var same = false;                                                     // 26
	_.each(offer.websites, function (website) {                           // 27
		if (website.url === rawOffer.websites[0].url) same = true;           // 28
	});                                                                   //
	return same;                                                          // 32
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=helper_offers.js.map
